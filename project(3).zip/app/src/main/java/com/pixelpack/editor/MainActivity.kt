package com.pixelpack.editor

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        // survives the short recreate() when changing settings
        var stash: Bitmap? = null
    }

    private lateinit var pixelView: PixelView
    private lateinit var colorChip: View
    private lateinit var selBar: LinearLayout
    private lateinit var prefs: SharedPreferences
    private val toolButtons = LinkedHashMap<Tool, Button>()

    private var btnSize = 1       // 0 small, 1 normal, 2 big
    private var barPos = 0        // 0 bottom, 1 top, 2 left (vertical)
    private var barVertical = false

    private val reqLoad = 1
    private val reqSave = 2
    private val reqPaste = 3

    // color history (index 0 = most recent previous color), 5 slots
    private val colorHistory = mutableListOf<Int>()
    private val histViews = ArrayList<View>()

    private val palette = intArrayOf(
        Color.rgb(0, 0, 0), Color.rgb(255, 255, 255), Color.rgb(127, 127, 127), Color.rgb(195, 195, 195),
        Color.rgb(136, 0, 21), Color.rgb(237, 28, 36), Color.rgb(255, 127, 39), Color.rgb(255, 242, 0),
        Color.rgb(34, 177, 76), Color.rgb(0, 162, 232), Color.rgb(63, 72, 204), Color.rgb(163, 73, 164),
        Color.rgb(185, 122, 87), Color.rgb(255, 174, 201), Color.rgb(255, 201, 14), Color.rgb(153, 217, 234)
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun btnH(): Int = dp(when (btnSize) { 0 -> 36; 2 -> 54; else -> 44 })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getPreferences(Context.MODE_PRIVATE)
        btnSize = prefs.getInt("btn_size", 1)
        barPos = prefs.getInt("bar_pos", 0)
        barVertical = barPos == 2

        pixelView = PixelView(this)
        colorChip = View(this)
        colorChip.setOnClickListener { showShades(pixelView.currentColor) }

        selBar = LinearLayout(this)
        selBar.orientation = LinearLayout.HORIZONTAL
        selBar.visibility = View.GONE
        buildSelBar()

        val root = LinearLayout(this)
        root.setBackgroundColor(Color.rgb(24, 24, 24))
        root.fitsSystemWindows = true

        val toolbarView = buildToolbar()
        if (barVertical) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(pixelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            col.addView(selBar)
            root.orientation = LinearLayout.HORIZONTAL
            root.addView(toolbarView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            root.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        } else {
            root.orientation = LinearLayout.VERTICAL
            if (barPos == 1) root.addView(toolbarView)
            root.addView(pixelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            root.addView(selBar)
            if (barPos == 0) root.addView(toolbarView)
        }
        setContentView(root)

        // restore art after a settings recreate()
        val s = stash
        if (s != null) {
            stash = null
            pixelView.loadBitmap(s)
        }

        // pick a color -> become the color AND jump back to pencil automatically
        pixelView.onColorPicked = { c ->
            setColor(c)
            selectTool(Tool.PENCIL)
        }
        pixelView.onSelectionChanged = { active ->
            selBar.visibility = if (active) View.VISIBLE else View.GONE
        }
        setColor(Color.BLACK)
        selectTool(Tool.PENCIL)
    }

    // ---------- UI building ----------

    private fun buildToolbar(): View {
        val row = LinearLayout(this)
        row.orientation = if (barVertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL

        // current color chip (tap = shades)
        val chipLp = LinearLayout.LayoutParams(dp(34), dp(34))
        chipLp.setMargins(dp(4), dp(4), dp(4), dp(4))
        row.addView(colorChip, chipLp)

        addToolButton(row, "\u270f\ufe0f Pencil", Tool.PENCIL, barVertical)

        val toolItems = mutableListOf<Pair<String, () -> Unit>>()
        toolItems.add(toolEntry(Tool.ERASER, "\uD83E\uDE79", "Eraser"))
        toolItems.add(toolEntry(Tool.FILL, "\uD83E\uDCA3", "Fill"))
        toolItems.add(toolEntry(Tool.PICKER, "\uD83C\uDFA8", "Pick"))
        addMenuButton(row, "\uD83D\uDCE0 Tools", toolItems, barVertical)

        addToolButton(row, "\u25e7 Select", Tool.SELECT, barVertical)
        addToolButton(row, "\u270b Hand", Tool.HAND, barVertical)
        addButton(row, "\u21b6 Undo", barVertical) { pixelView.undo() }
        addButton(row, "\u21b7 Redo", barVertical) { pixelView.redo() }
        addButton(row, "\u229e Grid", barVertical) { pixelView.showGrid = !pixelView.showGrid }
        addButton(row, "\uD83C\uDFA8 Colors", barVertical) { openColors() }
        addMenuButton(
            row, "\uD83D\uDCC1 File", listOf(
                "\uD83D\uDCBE Save PNG" to { saveImage() },
                "\uD83D\uDCC2 Load PNG" to { pickImage(reqLoad) },
                "\uD83D\uDCE5 Paste PNG" to { pickImage(reqPaste) }
            ), barVertical
        )
        addMenuButton(
            row, "\uD83D\uDDBC Canvas", listOf(
                "\uD83C\uDD95 New\u2026" to {
                    askSize("New canvas", 32, 32) { w, h -> pixelView.newCanvas(w, h) }
                },
                "\u2194\ufe0f Resize\u2026" to {
                    askSize("Resize canvas", pixelView.bitmap.width, pixelView.bitmap.height) { w, h ->
                        pixelView.resizeCanvas(w, h)
                    }
                },
                "\u2b1c Clear (transparent)" to { pixelView.clearCanvas() },
                "\uD83D\uDD8C Fill background" to { pixelView.fillBackground(pixelView.currentColor) }
            ), barVertical
        )
        addMenuButton(row, "\u2699 Settings", settingsItems(), barVertical)

        return if (barVertical) {
            val sv = ScrollView(this)
            sv.addView(row)
            sv
        } else {
            val hs = HorizontalScrollView(this)
            hs.addView(row)
            hs
        }
    }

    private fun toolEntry(t: Tool, icon: String, name: String): Pair<String, () -> Unit> {
        val lbl = (if (pixelView.tool == t) "\u2713 " else "") + icon + " " + name
        return lbl to { selectTool(t) }
    }

    private fun settingsItems(): List<Pair<String, () -> Unit>> {
        val sizeNames = arrayOf("Small", "Normal", "Big")
        val posNames = arrayOf("Bottom", "Top", "Left (vertical)")
        val items = mutableListOf<Pair<String, () -> Unit>>()
        for (s in 0..2) {
            val lbl = (if (btnSize == s) "\u2713 " else "") + "Button size: " + sizeNames[s]
            items.add(lbl to { setPref("btn_size", s) })
        }
        for (p in 0..2) {
            val lbl = (if (barPos == p) "\u2713 " else "") + "Toolbar: " + posNames[p]
            items.add(lbl to { setPref("bar_pos", p) })
        }
        return items
    }

    private fun setPref(key: String, v: Int) {
        prefs.edit().putInt(key, v).apply()
        pixelView.stampSelection()
        stash = pixelView.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        recreate()
    }

    private fun buildSelBar() {
        addButton(selBar, "\uD83D\uDCCB Copy") { pixelView.copySelection() }
        addButton(selBar, "\u27f3 Rotate") { pixelView.rotateSelection() }
        addButton(selBar, "\u21cb Flip H") { pixelView.flipSelection(true) }
        addButton(selBar, "\u21c5 Flip V") { pixelView.flipSelection(false) }
        addButton(selBar, "\u2713 Place") { pixelView.stampSelection() }
        addButton(selBar, "\u2715 Cancel") { pixelView.cancelSelection() }
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 13f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(10), 0, dp(10), 0)
        b.setBackgroundColor(Color.rgb(60, 60, 60))
        b.setTextColor(Color.WHITE)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addButton(row: LinearLayout, label: String, vertical: Boolean = false, onClick: () -> Unit) {
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(makeButton(label, onClick), lp)
    }

    private fun addMenuButton(row: LinearLayout, label: String, items: List<Pair<String, () -> Unit>>, vertical: Boolean = false) {
        val b = makeButton(label) {}
        b.setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            for (i in items.indices) {
                pm.menu.add(0, i, i, items[i].first)
            }
            pm.setOnMenuItemClickListener { mi ->
                items[mi.itemId].second()
                true
            }
            pm.show()
        }
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addToolButton(row: LinearLayout, label: String, t: Tool, vertical: Boolean = false) {
        val b = makeButton(label) { selectTool(t) }
        toolButtons[t] = b
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun selectTool(t: Tool) {
        pixelView.tool = t
        for ((tool, btn) in toolButtons) {
            if (tool == t) {
                btn.setBackgroundColor(Color.rgb(70, 110, 200))
            } else {
                btn.setBackgroundColor(Color.rgb(60, 60, 60))
            }
        }
    }

    private fun setColor(c: Int) {
        val old = pixelView.currentColor
        if (old != c) {
            colorHistory.add(0, old)
            while (colorHistory.size > 5) {
                colorHistory.removeAt(colorHistory.size - 1)
            }
        }
        pixelView.currentColor = c
        colorChip.setBackgroundColor(c)
        updateHistoryViews()
    }

    private fun updateHistoryViews() {
        for (i in histViews.indices) {
            val hv = histViews[i]
            if (i < colorHistory.size) {
                hv.visibility = View.VISIBLE
                hv.setBackgroundColor(colorHistory[i])
            } else {
                hv.visibility = View.INVISIBLE
            }
        }
    }

    // ---------- colors window ----------

    private fun openColors() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(4), dp(12), dp(4))

        // history rail
        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.gravity = Gravity.CENTER_VERTICAL
        histViews.clear()
        var dlg: AlertDialog? = null
        for (i in 0 until 5) {
            val hv = View(this)
            hv.setBackgroundColor(Color.WHITE)
            hv.setOnClickListener {
                if (i < colorHistory.size) {
                    setColor(colorHistory[i])
                    dlg?.dismiss()
                }
            }
            hv.setOnLongClickListener {
                if (i < colorHistory.size) showShades(colorHistory[i])
                true
            }
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            hrow.addView(hv, lp)
            histViews.add(hv)
        }
        box.addView(hrow)
        updateHistoryViews()

        // palette swatches
        val swrap = HorizontalScrollView(this)
        val srow = LinearLayout(this)
        srow.orientation = LinearLayout.HORIZONTAL
        srow.gravity = Gravity.CENTER_VERTICAL
        for (c in palette) {
            val sw = View(this)
            sw.setBackgroundColor(c)
            sw.setOnClickListener {
                setColor(c)
                dlg?.dismiss()
            }
            sw.setOnLongClickListener { showShades(c); true }
            val lp = LinearLayout.LayoutParams(dp(38), dp(38))
            lp.setMargins(dp(3), dp(6), dp(3), dp(6))
            srow.addView(sw, lp)
        }
        swrap.addView(srow)
        box.addView(swrap)

        val hexBtn = makeButton("#  Hex") {
            dlg?.dismiss()
            askHex()
        }
        box.addView(hexBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH()))

        dlg = AlertDialog.Builder(this)
            .setTitle("Colors")
            .setView(box)
            .setNegativeButton("Close", null)
            .create()
        dlg?.show()
    }

    // ---------- shade picker ----------

    private fun shadesOf(c: Int, steps: Int = 5): IntArray {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        val out = IntArray(steps * 2 + 1)
        for (i in -steps..steps) {
            val v = (hsv[2] * (1f + 0.13f * i)).coerceIn(0.02f, 1f)
            out[i + steps] = Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], v))
        }
        return out
    }

    private fun showShades(c: Int) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val scroll = HorizontalScrollView(this)
        scroll.addView(row)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Shades")
            .setView(scroll)
            .setNegativeButton("Cancel", null)
            .create()
        for (s in shadesOf(c)) {
            val sw = View(this)
            sw.setBackgroundColor(s)
            sw.setOnClickListener {
                setColor(s)
                dlg.dismiss()
            }
            val lp = LinearLayout.LayoutParams(dp(34), dp(44))
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            row.addView(sw, lp)
        }
        dlg.show()
    }

    // ---------- dialogs ----------

    private fun numberBox(v: Int): EditText {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(v.toString())
        return e
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        return tv
    }

    private fun askSize(title: String, defW: Int, defH: Int, onOk: (Int, Int) -> Unit) {
        val wBox = numberBox(defW)
        val hBox = numberBox(defH)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(label("Width (1-512)"))
        box.addView(wBox)
        box.addView(label("Height (1-512)"))
        box.addView(hBox)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val w = wBox.text.toString().toIntOrNull() ?: 0
                val h = hBox.text.toString().toIntOrNull() ?: 0
                if (w in 1..512 && h in 1..512) {
                    onOk(w, h)
                } else {
                    Toast.makeText(this, "Size must be 1 to 512", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askHex() {
        val box = EditText(this)
        box.hint = "RRGGBB"
        AlertDialog.Builder(this)
            .setTitle("Hex color")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                try {
                    val s = box.text.toString().trim().removePrefix("#")
                    setColor(Color.parseColor("#" + s) or Color.BLACK)
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid color", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- files ----------

    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.type = "image/*"
        startActivityForResult(Intent.createChooser(i, "Pick image"), req)
    }

    private fun saveImage() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_TITLE, "pixel.png")
        startActivityForResult(i, reqSave)
    }

    private fun decode(uri: Uri): Bitmap? {
        var bmp: Bitmap? = null
        try {
            val stream = contentResolver.openInputStream(uri)
            if (stream != null) {
                val o = BitmapFactory.Options()
                o.inScaled = false
                o.inPreferredConfig = Bitmap.Config.ARGB_8888
                bmp = BitmapFactory.decodeStream(stream, null, o)
                stream.close()
            }
        } catch (e: Exception) {
            bmp = null
        }
        if (bmp == null) {
            Toast.makeText(this, "Could not open image", Toast.LENGTH_SHORT).show()
            return null
        }
        if (bmp.width > 1024 || bmp.height > 1024) {
            Toast.makeText(this, "Image too big (max 1024x1024)", Toast.LENGTH_SHORT).show()
            return null
        }
        return bmp
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        if (requestCode == reqLoad) {
            val b = decode(uri)
            if (b != null) pixelView.loadBitmap(b)
        } else if (requestCode == reqPaste) {
            val b = decode(uri)
            if (b != null) pixelView.beginPaste(b)
        } else if (requestCode == reqSave) {
            try {
                val out = contentResolver.openOutputStream(uri)
                if (out != null) {
                    pixelView.bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.close()
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
