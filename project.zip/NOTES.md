# Pixel Pack Editor - notes

Build: upload project.zip to the repo; GitHub Actions (.github/workflows/build.yml) builds the debug APK.
The APK is signed with app/debug.keystore (fixed key), so new versions install over old ones.

Features (as of v0.8)
- Tools: Pencil, Eraser, Fill, Pick, Wand (same color), Select (rectangle), Hand; Dither toggle; Swap color
- Selection: move, rotate 90, flip H/V, copy, stamp, cancel; Paste PNG from file is a movable floating selection
- Menus: Tools, File (Save/Load/Paste PNG), Canvas (New/Resize/Clear/Fill background)
- Colors dialog with history and shades; settings cog (button size, toolbar position)
- Opens PNGs from other apps ("Open with" / Share) and via the system chooser (Load/Paste)
- Snap menu: save snapshots (kept on disk, newest 12), restore (undoable), compare overlay, delete
- File menu: Load/Paste PNG use Android's file browser; "(other app...)" variants use a chooser of any file app
