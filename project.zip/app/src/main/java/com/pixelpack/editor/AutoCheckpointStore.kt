package com.pixelpack.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class AutoCheckpointStore(context: Context) {
    private val directory = File(context.applicationContext.filesDir, "auto-checkpoints")
    private var lastSavedBitmap: Bitmap? = null

    @Synchronized
    fun restoreLatest(): Bitmap? {
        for (file in checkpointFiles()) {
            val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            if (bitmap != null) {
                lastSavedBitmap?.recycle()
                lastSavedBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                return bitmap
            }
            Log.w(TAG, "Ignoring unreadable auto-checkpoint: ${file.name}")
            file.delete()
        }
        return null
    }

    @Synchronized
    fun saveIfChanged(bitmap: Bitmap): Boolean {
        val previous = lastSavedBitmap
        if (
            previous != null &&
            previous.width == bitmap.width &&
            previous.height == bitmap.height &&
            previous.sameAs(bitmap)
        ) {
            return false
        }

        if (!directory.exists() && !directory.mkdirs()) {
            Log.e(TAG, "Could not create auto-checkpoint directory")
            return false
        }

        val timestamp = System.currentTimeMillis()
        val target = File(directory, "$timestamp.png")
        val temporary = File(directory, "$timestamp.tmp")
        try {
            FileOutputStream(temporary).use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                    throw IOException("Bitmap PNG compression failed")
                }
                output.fd.sync()
            }
            if (!temporary.renameTo(target)) {
                throw IOException("Could not finalize auto-checkpoint file")
            }

            lastSavedBitmap?.recycle()
            lastSavedBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false)
            pruneOldCheckpoints()
            return true
        } catch (error: Exception) {
            temporary.delete()
            Log.e(TAG, "Could not save auto-checkpoint", error)
            return false
        }
    }

    private fun checkpointFiles(): List<File> =
        directory.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".png") }
            ?.sortedByDescending { it.nameWithoutExtension.toLongOrNull() ?: 0L }
            ?: emptyList()

    private fun pruneOldCheckpoints() {
        checkpointFiles().drop(MAX_CHECKPOINTS).forEach { file ->
            if (!file.delete()) {
                Log.w(TAG, "Could not remove old auto-checkpoint: ${file.name}")
            }
        }
    }

    private companion object {
        const val TAG = "PixelJamCheckpoint"
        const val MAX_CHECKPOINTS = 48
    }
}
