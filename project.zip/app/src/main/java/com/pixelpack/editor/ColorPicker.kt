package com.pixelpack.editor

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class ColorPicker(private val context: Context) {

    var wandMode = false
        private set
    private var wandTargetColor: Int? = null
    private var wandReplaceColor: Int? = null
    var onWandSwap: ((Int, Int) -> Unit)? = null
    var onWandModeChanged: ((Boolean) -> Unit)? = null

    fun toggleWandMode() {
        wandMode = !wandMode
        if (wandMode) {
            wandTargetColor = null
            wandReplaceColor = null
            Toast.makeText(context, "Wand ON: Tap TARGET color", Toast.LENGTH_LONG).show()
        } else {
            wandTargetColor = null
            wandReplaceColor = null
            Toast.makeText(context, "Wand OFF", Toast.LENGTH_SHORT).show()
        }
        onWandModeChanged?.invoke(wandMode)
    }

    fun handleWandColorPick(color: Int) {
        if (!wandMode) return
        if (wandTargetColor == null) {
            wandTargetColor = color
            Toast.makeText(context, "Target set! Now tap REPLACEMENT color", Toast.LENGTH_LONG).show()
        } else if (wandReplaceColor == null) {
            wandReplaceColor = color
            onWandSwap?.invoke(wandTargetColor!!, wandReplaceColor!!)
            toggleWandMode()
        }
    }

    fun getWandTargetColor(): Int? = wandTargetColor
    fun getWandReplaceColor(): Int? = wandReplaceColor

    fun showPicker(initialColor: Int, onPick: (Int) -> Unit) {
        val box = LinearLayout(context)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(30, 20, 30, 20)

        val preview = View(context)
        preview.setBackgroundColor(initialColor)
        val previewLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 80)
        previewLp.setMargins(0, 0, 0, 20)
        box.addView(preview, previewLp)

        val hexBox = EditText(context)
        hexBox.hint = "Hex Color (e.g., FF0000)"
        hexBox.inputType = InputType.TYPE_CLASS_TEXT
        hexBox.setText(String.format("%06X", (0xFFFFFF and initialColor)))
        box.addView(hexBox)

        val hueText = TextView(context)
        hueText.text = "Hue: 0"
        hueText.setTextColor(Color.WHITE)
        hueText.setPadding(0, 15, 0, 5)
        val hueBar = SeekBar(context)
        hueBar.max = 360
        box.addView(hueText)
        box.addView(hueBar)

        val satText = TextView(context)
        satText.text = "Saturation: 100%"
        satText.setTextColor(Color.WHITE)
        satText.setPadding(0, 15, 0, 5)
        val satBar = SeekBar(context)
        satBar.max = 100
        satBar.progress = 100
        box.addView(satText)
        box.addView(satBar)

        val briText = TextView(context)
        briText.text = "Brightness: 100%"
        briText.setTextColor(Color.WHITE)
        briText.setPadding(0, 15, 0, 5)
        val briBar = SeekBar(context)
        briBar.max = 100
        briBar.progress = 100
        box.addView(briText)
        box.addView(briBar)

        val alphaText = TextView(context)
        alphaText.text = "Alpha: 255"
        alphaText.setTextColor(Color.WHITE)
        alphaText.setPadding(0, 15, 0, 5)
        val alphaBar = SeekBar(context)
        alphaBar.max = 255
        alphaBar.progress = Color.alpha(initialColor)
        box.addView(alphaText)
        box.addView(alphaBar)

        val updatePreview = {
            val h = hueBar.progress / 360f
            val s = satBar.progress / 100f
            val v = briBar.progress / 100f
            val rgb = Color.HSVToColor(floatArrayOf(h, s, v))
            val alpha = alphaBar.progress shl 24
            val finalColor = rgb or (alpha and 0xFF000000.toInt())
            preview.setBackgroundColor(finalColor)
            hueText.text = "Hue: ${hueBar.progress}"
            satText.text = "Saturation: ${satBar.progress}%"
            briText.text = "Brightness: ${briBar.progress}%"
            alphaText.text = "Alpha: ${alphaBar.progress}"
            hexBox.setText(String.format("%06X", (0xFFFFFF and finalColor)))
        }

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                updatePreview()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }

        hueBar.setOnSeekBarChangeListener(listener)
        satBar.setOnSeekBarChangeListener(listener)
        briBar.setOnSeekBarChangeListener(listener)
        alphaBar.setOnSeekBarChangeListener(listener)

        val hsv = FloatArray(3)
        Color.colorToHSV(initialColor, hsv)
        hueBar.progress = (hsv[0] * 360).toInt()
        satBar.progress = (hsv[1] * 100).toInt()
        briBar.progress = (hsv[2] * 100).toInt()
        updatePreview()

        AlertDialog.Builder(context)
            .setTitle("Color Picker")
            .setView(box)
            .setPositiveButton("Pick") { _, _ ->
                try {
                    val hex = hexBox.text.toString().trim().removePrefix("#")
                    val rgb = Color.parseColor("#$hex")
                    val alpha = alphaBar.progress shl 24
                    val finalColor = rgb or (alpha and 0xFF000000.toInt())
                    onPick(finalColor)
                } catch (e: Exception) {
                    Toast.makeText(context, "Invalid Hex", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}