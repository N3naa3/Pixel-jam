package com.pixelpack.editor

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class ColorPicker(private val context: Context) {

    var wandMode = false
        private set
    private var wandTargetColor: Int? = null
    private var wandReplaceColor: Int? = null
    var onWandSwap: ((Int, Int) -> Unit)? = null

    fun enterWandMode() {
        wandMode = true
        wandTargetColor = null
        wandReplaceColor = null
        Toast.makeText(context, "Wand Mode: Tap a color on canvas to select TARGET", Toast.LENGTH_LONG).show()
    }

    fun cancelWandMode() {
        wandMode = false
        wandTargetColor = null
        wandReplaceColor = null
    }

    fun handleWandColorPick(color: Int) {
        if (wandTargetColor == null) {
            wandTargetColor = color
            Toast.makeText(context, "Target set! Now tap the REPLACEMENT color", Toast.LENGTH_LONG).show()
        } else if (wandReplaceColor == null) {
            wandReplaceColor = color
            showWandConfirmationDialog()
        }
    }

    private fun showWandConfirmationDialog() {
        val target = wandTargetColor ?: return
        val replace = wandReplaceColor ?: return

        val box = LinearLayout(context)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(40, 20, 40, 20)
        box.gravity = Gravity.CENTER_HORIZONTAL

        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val targetView = View(context)
        targetView.setBackgroundColor(target)
        val lp1 = LinearLayout.LayoutParams(80, 80)
        lp1.setMargins(10, 10, 10, 10)
        row.addView(targetView, lp1)

        val arrow = TextView(context)
        arrow.text = "➔"
        arrow.textSize = 30f
        arrow.setTextColor(Color.WHITE)
        row.addView(arrow)

        val replaceView = View(context)
        replaceView.setBackgroundColor(replace)
        val lp2 = LinearLayout.LayoutParams(80, 80)
        lp2.setMargins(10, 10, 10, 10)
        row.addView(replaceView, lp2)

        box.addView(row)

        val warn = TextView(context)
        warn.text = "Replace ALL instances of the left color with the right color?"
        warn.setTextColor(Color.LTGRAY)
        warn.gravity = Gravity.CENTER
        warn.setPadding(0, 20, 0, 20)
        box.addView(warn)

        AlertDialog.Builder(context)
            .setTitle("Confirm Color Swap")
            .setView(box)
            .setPositiveButton("SWAP") { _, _ ->
                onWandSwap?.invoke(target, replace)
                cancelWandMode()
            }
            .setNegativeButton("Cancel") { _, _ -> cancelWandMode() }
            .setNeutralButton("Pick Again") { _, _ -> 
                wandTargetColor = null
                wandReplaceColor = null
                Toast.makeText(context, "Tap TARGET color again", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    fun showPicker(initialColor: Int, onPick: (Int) -> Unit) {
        val box = LinearLayout(context)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(30, 20, 30, 20)

        val preview = View(context)
        preview.setBackgroundColor(initialColor)
        val previewLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 80)
        previewLp.setMargins(0, 0, 0, 20)
        box.addView(preview, previewLp)

        val hexBox = EditText(context)
        hexBox.hint = "Hex Color (e.g., FF0000)"
        hexBox.inputType = InputType.TYPE_CLASS_TEXT
        hexBox.setText(String.format("%06X", (0xFFFFFF and initialColor)))
        box.addView(hexBox)

        val hueText = TextView(context).apply { text = "Hue: 0"; setTextColor(Color.WHITE); setPadding(0, 15, 0, 5) }
        val hueBar = SeekBar(context).apply { max = 360 }
        box.addView(hueText)
        box.addView(hueBar)

        val satText = TextView(context).apply { text = "Saturation: 100%"; setTextColor(Color.WHITE); setPadding(0, 15, 0, 5) }
        val satBar = SeekBar(context).apply { max = 100; progress = 100 }
        box.addView(satText)
        box.addView(satBar)

        val briText = TextView(context).apply { text = "Brightness: 100%"; setTextColor(Color.WHITE); setPadding(0, 15, 0, 5) }
        val briBar = SeekBar(context).apply { max = 100; progress = 100 }
        box.addView(briText)
        box.addView(briBar)

        val alphaText = TextView(context).apply { text = "Alpha: 255"; setTextColor(Color.WHITE); setPadding(0, 15, 0, 5) }
        val alphaBar = SeekBar(context).apply { max = 255; progress = Color.alpha(initialColor) }
        box.addView(alphaText)
        box.addView(alphaBar)

        val updatePreview = {
            val h = hueBar.progress / 360f
            val s = satBar.progress / 100f
            val v = briBar.progress / 100f
            val rgb = Color.HSVToColor(floatArrayOf(h, s, v))
            val alpha = alphaBar.progress shl 24
            val finalColor = rgb or (alpha and 0xFF000000.toInt())
            preview.setBackgroundColor(finalColor)
            hueText.text = "Hue: ${hueBar.progress}"
            satText.text = "Saturation: ${satBar.progress}%"
            briText.text = "Brightness: ${briBar.progress}%"
            alphaText.text = "Alpha: ${alphaBar.progress}"
            hexBox.setText(String.format("%06X", (0xFFFFFF and finalColor)))
        }

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { updatePreview() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        
        // FIXED: Using setOnSeekBarChangeListener instead of property assignment
        hueBar.setOnSeekBarChangeListener(listener)
        satBar.setOnSeekBarChangeListener(listener)
        briBar.setOnSeekBarChangeListener(listener)
        alphaBar.setOnSeekBarChangeListener(listener)

        val hsv = FloatArray(3)
        Color.colorToHSV(initialColor, hsv)
        hueBar.progress = (hsv[0] * 360).toInt()
        satBar.progress = (hsv[1] * 100).toInt()
        briBar.progress = (hsv[2] * 100).toInt()
        updatePreview()

        AlertDialog.Builder(context)
            .setTitle("Color Picker")
            .setView(box)
            .setPositiveButton("Pick") { _, _ ->
                try {
                    val hex = hexBox.text.toString().trim().removePrefix("#")
                    val rgb = Color.parseColor("#$hex")
                    val alpha = alphaBar.progress shl 24
                    val finalColor = rgb or (alpha and 0xFF000000.toInt())
                    onPick(finalColor)
                } catch (e: Exception) {
                    Toast.makeText(context, "Invalid Hex", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}