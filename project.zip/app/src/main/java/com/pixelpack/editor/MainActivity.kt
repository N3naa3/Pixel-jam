package com.pixelpack.editor

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private enum class ToolbarIcon { PENCIL, PICKER, FILL, ERASER, HAND, UNDO, REDO }

    private lateinit var pixelView: PixelView
    private lateinit var checkpointStore: AutoCheckpointStore
    private val toolButtons = LinkedHashMap<Tool, FrameLayout>()
    private val checkpointHandler = Handler(Looper.getMainLooper())
    private val checkpointInProgress = AtomicBoolean(false)
    private val checkpointPending = AtomicBoolean(false)
    private val checkpointIntervalMs = 3 * 60 * 1000L
    private val checkpointRunnable = object : Runnable {
        override fun run() {
            saveCheckpoint()
            checkpointHandler.postDelayed(this, checkpointIntervalMs)
        }
    }

    private val reqLoad = 1
    private val reqSave = 2
    private val reqPaste = 3

    private val colorHistory = mutableListOf<Int>()
    private val histViews = ArrayList<View>()

    private val palette = intArrayOf(
        Color.rgb(0, 0, 0), Color.rgb(255, 255, 255), Color.rgb(127, 127, 127), Color.rgb(195, 195, 195),
        Color.rgb(136, 0, 21), Color.rgb(237, 28, 36), Color.rgb(255, 127, 39), Color.rgb(255, 242, 0),
        Color.rgb(34, 177, 76), Color.rgb(0, 162, 232), Color.rgb(63, 72, 204), Color.rgb(163, 73, 164),
        Color.rgb(185, 122, 87), Color.rgb(255, 174, 201), Color.rgb(255, 201, 14), Color.rgb(153, 217, 234)
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun btnH(): Int = dp(48)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkpointStore = AutoCheckpointStore(applicationContext)
        pixelView = PixelView(this)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setBackgroundColor(Color.rgb(24, 24, 24))
        content.addView(buildToolbar(), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            btnH() + dp(4)
        ))
        content.addView(
            pixelView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(content)

        val recovered = checkpointStore.restoreLatest()
        if (recovered != null) {
            pixelView.loadBitmap(recovered)
            recovered.recycle()
            Toast.makeText(this, "Recovered latest auto-checkpoint", Toast.LENGTH_SHORT).show()
        }

        pixelView.onColorPicked = { c ->
            setColor(c)
            selectTool(Tool.PENCIL)
        }
        setColor(Color.BLACK)
        selectTool(Tool.PENCIL)
    }

    override fun onResume() {
        super.onResume()
        checkpointHandler.removeCallbacks(checkpointRunnable)
        checkpointHandler.postDelayed(checkpointRunnable, checkpointIntervalMs)
    }

    override fun onPause() {
        checkpointHandler.removeCallbacks(checkpointRunnable)
        saveCheckpoint(synchronous = true)
        super.onPause()
    }

    private fun saveCheckpoint(synchronous: Boolean = false) {
        if (!::pixelView.isInitialized) return
        if (synchronous) {
            val snapshot = pixelView.checkpointBitmap()
            try {
                checkpointStore.saveIfChanged(snapshot)
            } finally {
                snapshot.recycle()
            }
            return
        }
        if (!checkpointInProgress.compareAndSet(false, true)) {
            checkpointPending.set(true)
            return
        }
        val snapshot = pixelView.checkpointBitmap()
        Thread {
            try {
                checkpointStore.saveIfChanged(snapshot)
            } finally {
                snapshot.recycle()
                checkpointInProgress.set(false)
                if (checkpointPending.getAndSet(false)) {
                    checkpointHandler.post { saveCheckpoint() }
                }
            }
        }.start()
    }

    // ---------- UI building ----------

    private fun buildToolbar(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        addToolButton(row, ToolbarIcon.PENCIL, Tool.PENCIL, "Pencil")
        addToolButton(row, ToolbarIcon.PICKER, Tool.PICKER, "Pick color")
        addToolButton(row, ToolbarIcon.FILL, Tool.FILL, "Fill")
        addToolButton(row, ToolbarIcon.ERASER, Tool.ERASER, "Eraser")
        addToolButton(row, ToolbarIcon.HAND, Tool.HAND, "Pan canvas")
        addIconActionButton(row, ToolbarIcon.UNDO, "Undo") { pixelView.undo() }
        addIconActionButton(row, ToolbarIcon.REDO, "Redo") { pixelView.redo() }
        addMenuButtonDynamic(row, "\u22ee", { overflowItems() }, false)

        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.addView(row)
        return scroll
    }

    private fun overflowItems(): List<Pair<String, () -> Unit>> {
        val gridLabel = if (pixelView.showGrid) "Hide grid" else "Show grid"
        return listOf(
            "Select region" to { selectTool(Tool.SELECT) },
            "Select same color" to { selectTool(Tool.WAND) },
            "Replace color\u2026" to {
                pixelView.requestSwap()
                Toast.makeText(this, "Tap a pixel of the color to replace everywhere", Toast.LENGTH_LONG).show()
            },
            gridLabel to { pixelView.showGrid = !pixelView.showGrid },
            "Colors\u2026" to { openColors() },
            "Shades of current color" to { showShades(pixelView.currentColor) },
            "Save PNG" to { saveImage() },
            "Load PNG" to { pickImage(reqLoad) },
            "Paste PNG" to { pickImage(reqPaste) },
            "New canvas\u2026" to { askSize("New canvas", 32, 32) { w, h -> pixelView.newCanvas(w, h) } },
            "Resize canvas\u2026" to {
                askSize("Resize canvas", pixelView.bitmap.width, pixelView.bitmap.height) { w, h ->
                    pixelView.resizeCanvas(w, h)
                }
            },
            "Clear canvas" to { pixelView.clearCanvas() },
            "Fill background" to { pixelView.fillBackground(pixelView.currentColor) },
            "Settings\u2026" to { openSettings() }
        )
    }

    // ---------- settings panel ----------

    private fun openSettings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(4))

        // ghost blocks preview: checkbox + size slider
        val ghostCb = CheckBox(this)
        ghostCb.text = "\uD83D\uDC7B Ghost blocks preview"
        ghostCb.isChecked = pixelView.ghostN > 1
        box.addView(ghostCb)

        val ghostVal = label("")
        val ghostBar = SeekBar(this)
        ghostBar.max = 3
        if (pixelView.ghostN > 1) {
            ghostBar.progress = pixelView.ghostN - 2
            ghostVal.text = "Size: " + pixelView.ghostN + "x" + pixelView.ghostN
        } else {
            ghostBar.progress = 1
            ghostVal.text = "Size: 3x3"
        }
        box.addView(ghostVal)
        box.addView(ghostBar)

        ghostCb.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                pixelView.setGhost(ghostBar.progress + 2)
            } else {
                pixelView.setGhost(0)
            }
        }
        ghostBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + 2
                ghostVal.text = "Size: " + n + "x" + n
                if (ghostCb.isChecked) {
                    pixelView.setGhost(n)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // pencil brush slider
        val brushVal = label("")
        val brushBar = SeekBar(this)
        brushBar.max = 2
        brushBar.progress = pixelView.brushSize - 1
        brushVal.text = "Pencil brush: " + pixelView.brushSize + "x" + pixelView.brushSize
        box.addView(brushVal)
        box.addView(brushBar)
        brushBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + 1
                pixelView.brushSize = n
                brushVal.text = "Pencil brush: " + n + "x" + n
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // eraser size slider
        val eraserVal = label("")
        val eraserBar = SeekBar(this)
        eraserBar.max = 2
        eraserBar.progress = pixelView.eraserSize - 1
        eraserVal.text = "Eraser size: " + pixelView.eraserSize + "x" + pixelView.eraserSize
        box.addView(eraserVal)
        box.addView(eraserBar)
        eraserBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + 1
                pixelView.eraserSize = n
                eraserVal.text = "Eraser size: " + n + "x" + n
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(box)
            .setNegativeButton("Close", null)
            .show()
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 13f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(10), 0, dp(10), 0)
        b.setBackgroundColor(Color.rgb(60, 60, 60))
        b.setTextColor(Color.WHITE)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addButton(row: LinearLayout, label: String, vertical: Boolean = false, onClick: () -> Unit) {
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(makeButton(label, onClick), lp)
    }

    private fun addMenuButton(row: LinearLayout, label: String, items: List<Pair<String, () -> Unit>>, vertical: Boolean = false) {
        val b = makeButton(label) {}
        b.setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            for (i in items.indices) {
                pm.menu.add(0, i, i, items[i].first)
            }
            pm.setOnMenuItemClickListener { mi ->
                items[mi.itemId].second()
                true
            }
            pm.show()
        }
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addMenuButtonDynamic(row: LinearLayout, label: String, provider: () -> List<Pair<String, () -> Unit>>, vertical: Boolean) {
        val b = makeButton(label) {}
        if (label == "\u22ee") {
            b.contentDescription = "More tools and actions"
            b.textSize = 24f
        }
        b.setOnClickListener { v ->
            val list = provider()
            val pm = PopupMenu(this, v)
            for (i in list.indices) {
                pm.menu.add(0, i, i, list[i].first)
            }
            pm.setOnMenuItemClickListener { mi ->
                list[mi.itemId].second()
                true
            }
            pm.show()
        }
        val lp = if (label == "\u22ee") {
            LinearLayout.LayoutParams(dp(44), btnH())
        } else if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addToolButton(row: LinearLayout, icon: ToolbarIcon, t: Tool, description: String) {
        val b = FrameLayout(this)
        b.contentDescription = description
        b.isClickable = true
        b.isFocusable = true
        b.background = iconButtonBackground(Color.rgb(60, 60, 60))
        b.addView(
            ToolbarGlyphView(this, icon),
            FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
        )
        b.setOnClickListener { selectTool(t) }
        toolButtons[t] = b
        val lp = LinearLayout.LayoutParams(dp(46), btnH())
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addIconActionButton(
        row: LinearLayout,
        icon: ToolbarIcon,
        description: String,
        onClick: () -> Unit
    ) {
        val button = FrameLayout(this)
        button.contentDescription = description
        button.isClickable = true
        button.isFocusable = true
        button.background = iconButtonBackground(Color.rgb(60, 60, 60))
        button.addView(
            ToolbarGlyphView(this, icon),
            FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
        )
        button.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(dp(46), btnH())
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(button, lp)
    }

    private fun iconButtonBackground(color: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(8).toFloat()
            setColor(color)
        }

    private fun selectTool(t: Tool) {
        pixelView.tool = t
        for ((tool, btn) in toolButtons) {
            val color = if (tool == t) Color.rgb(70, 110, 200) else Color.rgb(60, 60, 60)
            btn.background = iconButtonBackground(color)
        }
    }

    private fun setColor(c: Int) {
        val old = pixelView.currentColor
        if (old != c) {
            colorHistory.add(0, old)
            while (colorHistory.size > 5) {
                colorHistory.removeAt(colorHistory.size - 1)
            }
        }
        pixelView.currentColor = c
        updateHistoryViews()
    }

    private fun updateHistoryViews() {
        for (i in histViews.indices) {
            val hv = histViews[i]
            if (i < colorHistory.size) {
                hv.visibility = View.VISIBLE
                hv.setBackgroundColor(colorHistory[i])
            } else {
                hv.visibility = View.INVISIBLE
            }
        }
    }

    // ---------- colors window ----------

    private fun openColors() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(4), dp(12), dp(4))

        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.gravity = Gravity.CENTER_VERTICAL
        histViews.clear()
        var dlg: AlertDialog? = null
        for (i in 0 until 5) {
            val hv = View(this)
            hv.setBackgroundColor(Color.WHITE)
            hv.setOnClickListener {
                if (i < colorHistory.size) {
                    setColor(colorHistory[i])
                    dlg?.dismiss()
                }
            }
            hv.setOnLongClickListener {
                if (i < colorHistory.size) showShades(colorHistory[i])
                true
            }
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            hrow.addView(hv, lp)
            histViews.add(hv)
        }
        box.addView(hrow)
        updateHistoryViews()

        val swrap = HorizontalScrollView(this)
        val srow = LinearLayout(this)
        srow.orientation = LinearLayout.HORIZONTAL
        srow.gravity = Gravity.CENTER_VERTICAL
        for (c in palette) {
            val sw = View(this)
            sw.setBackgroundColor(c)
            sw.setOnClickListener {
                setColor(c)
                dlg?.dismiss()
            }
            sw.setOnLongClickListener { showShades(c); true }
            val lp = LinearLayout.LayoutParams(dp(38), dp(38))
            lp.setMargins(dp(3), dp(6), dp(3), dp(6))
            srow.addView(sw, lp)
        }
        swrap.addView(srow)
        box.addView(swrap)

        val hexBtn = makeButton("#  Hex") {
            dlg?.dismiss()
            askHex()
        }
        box.addView(hexBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH()))

        dlg = AlertDialog.Builder(this)
            .setTitle("Colors")
            .setView(box)
            .setNegativeButton("Close", null)
            .create()
        dlg?.show()
    }

    // ---------- shade picker ----------

    private fun shadesOf(c: Int, steps: Int = 5): IntArray {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        val out = IntArray(steps * 2 + 1)
        for (i in -steps..steps) {
            val v = (hsv[2] * (1f + 0.13f * i)).coerceIn(0.02f, 1f)
            out[i + steps] = Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], v))
        }
        return out
    }

    private fun showShades(c: Int) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val scroll = HorizontalScrollView(this)
        scroll.addView(row)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Shades")
            .setView(scroll)
            .setNegativeButton("Cancel", null)
            .create()
        for (s in shadesOf(c)) {
            val sw = View(this)
            sw.setBackgroundColor(s)
            sw.setOnClickListener {
                setColor(s)
                dlg.dismiss()
            }
            val lp = LinearLayout.LayoutParams(dp(34), dp(44))
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            row.addView(sw, lp)
        }
        dlg.show()
    }

    // ---------- dialogs ----------

    private fun numberBox(v: Int): EditText {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(v.toString())
        return e
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        return tv
    }

    private fun askSize(title: String, defW: Int, defH: Int, onOk: (Int, Int) -> Unit) {
        val wBox = numberBox(defW)
        val hBox = numberBox(defH)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(label("Width (1-512)"))
        box.addView(wBox)
        box.addView(label("Height (1-512)"))
        box.addView(hBox)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val w = wBox.text.toString().toIntOrNull() ?: 0
                val h = hBox.text.toString().toIntOrNull() ?: 0
                if (w in 1..512 && h in 1..512) {
                    onOk(w, h)
                } else {
                    Toast.makeText(this, "Size must be 1 to 512", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askHex() {
        val box = EditText(this)
        box.hint = "RRGGBB"
        AlertDialog.Builder(this)
            .setTitle("Hex color")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                try {
                    val s = box.text.toString().trim().removePrefix("#")
                    setColor(Color.parseColor("#" + s) or Color.BLACK)
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid color", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- files ----------

    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.type = "image/*"
        startActivityForResult(Intent.createChooser(i, "Pick image"), req)
    }

    private fun saveImage() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_TITLE, "pixel.png")
        startActivityForResult(i, reqSave)
    }

    private fun decode(uri: Uri): Bitmap? {
        var bmp: Bitmap? = null
        try {
            val stream = contentResolver.openInputStream(uri)
            if (stream != null) {
                val o = BitmapFactory.Options()
                o.inScaled = false
                o.inPreferredConfig = Bitmap.Config.ARGB_8888
                bmp = BitmapFactory.decodeStream(stream, null, o)
                stream.close()
            }
        } catch (e: Exception) {
            bmp = null
        }
        if (bmp == null) {
            Toast.makeText(this, "Could not open image", Toast.LENGTH_SHORT).show()
            return null
        }
        if (bmp.width > 1024 || bmp.height > 1024) {
            Toast.makeText(this, "Image too big (max 1024x1024)", Toast.LENGTH_SHORT).show()
            return null
        }
        return bmp
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        if (requestCode == reqLoad) {
            val b = decode(uri)
            if (b != null) pixelView.loadBitmap(b)
        } else if (requestCode == reqPaste) {
            val b = decode(uri)
            if (b != null) pixelView.beginPaste(b)
        } else if (requestCode == reqSave) {
            try {
                val out = contentResolver.openOutputStream(uri)
                if (out != null) {
                    pixelView.bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.close()
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private inner class ToolbarGlyphView(
        context: Context,
        private val icon: ToolbarIcon
    ) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 2f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val side = minOf(width, height).toFloat()
            canvas.save()
            canvas.translate((width - side) / 2f, (height - side) / 2f)
            canvas.scale(side / 24f, side / 24f)

            when (icon) {
                ToolbarIcon.PENCIL -> drawPencil(canvas)
                ToolbarIcon.PICKER -> drawDropper(canvas)
                ToolbarIcon.FILL -> drawBucket(canvas)
                ToolbarIcon.ERASER -> drawEraser(canvas)
                ToolbarIcon.HAND -> drawHand(canvas)
                ToolbarIcon.UNDO -> drawCurvedArrow(canvas, mirrored = false)
                ToolbarIcon.REDO -> drawCurvedArrow(canvas, mirrored = true)
            }

            canvas.restore()
        }

        private fun drawPencil(canvas: Canvas) {
            paint.color = Color.WHITE
            paint.style = Paint.Style.FILL
            val body = Path().apply {
                moveTo(4f, 18f)
                lineTo(17f, 5f)
                lineTo(20f, 8f)
                lineTo(7f, 21f)
                close()
            }
            canvas.drawPath(body, paint)
            paint.color = Color.rgb(255, 207, 92)
            val tip = Path().apply {
                moveTo(4f, 18f)
                lineTo(7f, 21f)
                lineTo(3f, 22f)
                close()
            }
            canvas.drawPath(tip, paint)
            paint.style = Paint.Style.STROKE
            paint.color = Color.rgb(70, 70, 70)
            canvas.drawLine(7f, 18f, 17f, 8f, paint)
        }

        private fun drawDropper(canvas: Canvas) {
            paint.color = Color.WHITE
            paint.style = Paint.Style.FILL
            val tube = Path().apply {
                moveTo(15f, 3f)
                lineTo(21f, 9f)
                lineTo(10f, 20f)
                lineTo(6f, 21f)
                lineTo(7f, 17f)
                close()
            }
            canvas.drawPath(tube, paint)
            paint.style = Paint.Style.STROKE
            paint.color = Color.rgb(65, 65, 65)
            canvas.drawLine(12f, 6f, 18f, 12f, paint)
            paint.color = Color.rgb(90, 190, 255)
            paint.style = Paint.Style.FILL
            val drop = Path().apply {
                moveTo(5f, 15f)
                cubicTo(2f, 18f, 2f, 20f, 5f, 21f)
                cubicTo(8f, 20f, 8f, 18f, 5f, 15f)
                close()
            }
            canvas.drawPath(drop, paint)
        }

        private fun drawBucket(canvas: Canvas) {
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            canvas.drawArc(RectF(5f, 3f, 19f, 17f), 190f, 160f, false, paint)
            val bucket = Path().apply {
                moveTo(5f, 9f)
                lineTo(7f, 20f)
                lineTo(18f, 20f)
                lineTo(20f, 9f)
            }
            canvas.drawPath(bucket, paint)
            canvas.drawLine(4f, 9f, 21f, 9f, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(90, 190, 255)
            val drop = Path().apply {
                moveTo(16f, 11f)
                cubicTo(14f, 14f, 14f, 16f, 16f, 17f)
                cubicTo(18f, 16f, 18f, 14f, 16f, 11f)
                close()
            }
            canvas.drawPath(drop, paint)
        }

        private fun drawEraser(canvas: Canvas) {
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(255, 105, 180)
            val eraser = Path().apply {
                moveTo(8f, 4f)
                lineTo(21f, 13f)
                lineTo(15f, 21f)
                lineTo(3f, 12f)
                close()
            }
            canvas.drawPath(eraser, paint)
            paint.color = Color.rgb(255, 190, 220)
            val end = Path().apply {
                moveTo(3f, 12f)
                lineTo(8f, 4f)
                lineTo(14f, 9f)
                lineTo(8f, 17f)
                close()
            }
            canvas.drawPath(end, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            canvas.drawLine(8f, 17f, 14f, 9f, paint)
        }

        private fun drawHand(canvas: Canvas) {
            paint.color = Color.WHITE
            paint.style = Paint.Style.FILL
            val hand = Path().apply {
                moveTo(6f, 12f)
                lineTo(6f, 9f)
                cubicTo(6f, 7f, 9f, 7f, 9f, 9f)
                lineTo(9f, 4f)
                cubicTo(9f, 2f, 12f, 2f, 12f, 4f)
                lineTo(12f, 8f)
                lineTo(13f, 3f)
                cubicTo(13.5f, 1f, 16f, 2f, 16f, 4f)
                lineTo(16f, 9f)
                lineTo(17f, 6f)
                cubicTo(18f, 4f, 20f, 5f, 20f, 7f)
                lineTo(20f, 14f)
                cubicTo(20f, 20f, 16f, 22f, 12f, 22f)
                cubicTo(9f, 22f, 8f, 19f, 6f, 17f)
                lineTo(3f, 14f)
                cubicTo(2f, 12f, 4f, 10f, 6f, 12f)
                close()
            }
            canvas.drawPath(hand, paint)
        }

        private fun drawCurvedArrow(canvas: Canvas, mirrored: Boolean) {
            canvas.save()
            if (mirrored) canvas.scale(-1f, 1f, 12f, 12f)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            canvas.drawArc(RectF(5f, 5f, 19f, 19f), 215f, 280f, false, paint)
            val arrow = Path().apply {
                moveTo(4f, 6f)
                lineTo(10f, 6f)
                lineTo(6f, 11f)
                close()
            }
            paint.style = Paint.Style.FILL
            canvas.drawPath(arrow, paint)
            canvas.restore()
        }
    }
}
