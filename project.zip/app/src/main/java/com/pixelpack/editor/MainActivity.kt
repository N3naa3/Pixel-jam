package com.pixelpack.editor

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        var stash: Bitmap? = null
    }

    private lateinit var pixelView: PixelView
    private lateinit var colorChip: View
    private lateinit var prefs: SharedPreferences
    private val toolButtons = LinkedHashMap<Tool, Button>()
    private var btnSize = 1
    private var barPos = 0
    private var barVertical = false
    private val reqLoad = 1
    private val reqSave = 2
    private val reqPaste = 3
    private val colorHistory = mutableListOf<Int>()
    private val histViews = ArrayList<View>()
    private val colorPicker = ColorPicker(this)

    // FEATURE 1: Language Toggle
    private var appLanguage = "en" // "en" or "ar"
    private fun tr(en: String, ar: String): String = if (appLanguage == "ar") ar else en

    private val palette = intArrayOf(
        Color.rgb(0, 0, 0), Color.rgb(255, 255, 255), Color.rgb(127, 127, 127), Color.rgb(195, 195, 195),
        Color.rgb(136, 0, 21), Color.rgb(237, 28, 36), Color.rgb(255, 127, 39), Color.rgb(255, 242, 0),
        Color.rgb(34, 177, 76), Color.rgb(0, 162, 232), Color.rgb(63, 72, 204), Color.rgb(163, 73, 164),
        Color.rgb(185, 122, 87), Color.rgb(255, 174, 201), Color.rgb(255, 201, 14), Color.rgb(153, 217, 234)
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun btnH(): Int = dp(when (btnSize) { 0 -> 36; 2 -> 54; else -> 44 })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getPreferences(Context.MODE_PRIVATE)
        btnSize = prefs.getInt("btn_size", 1)
        barPos = prefs.getInt("bar_pos", 0)
        barVertical = barPos == 2
        appLanguage = prefs.getString("app_language", "en") ?: "en"

        pixelView = PixelView(this)
        colorChip = View(this)
        colorChip.setOnClickListener { showShades(pixelView.currentColor) }

        val content = LinearLayout(this)
        content.setBackgroundColor(Color.rgb(24, 24, 24))

        val toolbarView = buildToolbar()
        resizePanel = buildResizePanel()
        resizePanel.visibility = View.GONE

        if (barVertical) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(pixelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            col.addView(resizePanel)
            content.orientation = LinearLayout.HORIZONTAL
            content.addView(toolbarView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            content.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        } else {
            content.orientation = LinearLayout.VERTICAL
            if (barPos == 1) content.addView(toolbarView)
            content.addView(pixelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            content.addView(resizePanel)
            if (barPos == 0) content.addView(toolbarView)
        }

        val root = FrameLayout(this)
        root.fitsSystemWindows = true
        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val cog = makeButton("\u2699") {}
        cog.textSize = 26f
        cog.setOnClickListener { openSettings() }
        val clp = FrameLayout.LayoutParams(dp(54), dp(54), Gravity.TOP or Gravity.END)
        val cogTop: Int
        if (barPos == 1) {
            cogTop = dp(8) + btnH() + dp(4)
        } else {
            cogTop = dp(8)
        }
        clp.setMargins(dp(8), cogTop, dp(8), dp(8))
        root.addView(cog, clp)
        setContentView(root)

        val s = stash
        if (s != null) {
            stash = null
            pixelView.loadBitmap(s)
        }

        // FEATURE 4: Wand Swap Logic
        colorPicker.onWandSwap = { target, replacement ->
            pixelView.replaceColor(target, replacement)
            Toast.makeText(this, tr("Colors swapped!", "تم استبدال الألوان!"), Toast.LENGTH_SHORT).show()
            updateWandMenuVisibility()
        }
        colorPicker.onWandModeChanged = { isOn ->
            updateWandMenuVisibility()
        }

        pixelView.onColorPicked = { c ->
            if (colorPicker.wandMode) {
                colorPicker.handleWandColorPick(c)
                updateWandMenuVisibility()
            } else {
                setColor(c)
                selectTool(Tool.PENCIL)
            }
        }

        setColor(Color.BLACK)
        selectTool(Tool.PENCIL)

        if (savedInstanceState == null) handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    private fun handleIncoming(intent: Intent?) {
        if (intent == null) return
        var uri: Uri? = null
        if (intent.action == Intent.ACTION_VIEW) {
            uri = intent.data
        } else if (intent.action == Intent.ACTION_SEND) {
            uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
        if (uri == null) return
        val u: Uri = uri
        val b = decode(u) ?: return
        AlertDialog.Builder(this)
            .setTitle(tr("Open image", "فتح الصورة"))
            .setMessage(tr("What do you want to do with it?", "ماذا تريد أن تفعل بها؟"))
            .setPositiveButton(tr("Open as new canvas", "فتح كلوحة جديدة")) { _, _ -> pixelView.loadBitmap(b) }
            .setNeutralButton(tr("Paste onto canvas", "لصق على اللوحة")) { _, _ ->
                pixelView.beginPaste(b)
                selectTool(Tool.SELECT)
            }
            .setNegativeButton(tr("Cancel", "إلغاء"), null)
            .show()
    }

    private fun buildToolbar(): View {
        val row = LinearLayout(this)
        row.orientation = if (barVertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL

        val chipLp = LinearLayout.LayoutParams(dp(34), dp(34))
        chipLp.setMargins(dp(4), dp(4), dp(4), dp(4))
        row.addView(colorChip, chipLp)

        addToolButton(row, tr("✏️ Pencil", "قلم ✏️"), Tool.PENCIL, barVertical)
        addMenuButtonDynamic(row, tr("📦 Tools", "أدوات 📦"), { toolsItems() }, barVertical)
        addToolButton(row, tr("◧ Select", "تحديد ◧"), Tool.SELECT, barVertical)
        addToolButton(row, tr("✋ Hand", "يد ✋"), Tool.HAND, barVertical)
        addButton(row, tr("↶ Undo", "تراجع ↶"), barVertical) { pixelView.undo() }
        addButton(row, tr("↷ Redo", "إعادة ↷"), barVertical) { pixelView.redo() }
        addMenuButtonDynamic(row, tr("🔖 Snap", "لقطة 🔖"), { snapItems() }, barVertical)
        addButton(row, tr("⊞ Grid", "شبكة "), barVertical) { pixelView.showGrid = !pixelView.showGrid }
        addButton(row, tr("🎨 Colors", "ألوان 🎨"), barVertical) { openColors() }
        addMenuButton(
            row, tr("📁 File", "ملف 📁"), listOf(
                tr("💾 Save PNG", "حفظ PNG 💾") to { saveImage() },
                tr("📂 Load PNG", "تحميل PNG 📂") to { pickImage(reqLoad) },
                tr("📥 Paste PNG", "لصق PNG 📥") to { pickImage(reqPaste) }
            ), barVertical
        )
        addMenuButton(
            row, tr("🖼 Canvas", "لوحة 🖼"), listOf(
                tr("🆕 New…", "جديد 🆕…") to {
                    askSize(tr("New canvas", "لوحة جديدة"), 32, 32) { w, h -> pixelView.newCanvas(w, h) }
                },
                tr("↔️ Resize…", "تغيير الحجم ↔️…") to { openResizePanel() },
                tr("⬜ Clear", "مسح ⬜") to { pixelView.clearCanvas() }
            ), barVertical
        )

        return if (barVertical) {
            val sv = ScrollView(this)
            sv.addView(row)
            sv
        } else {
            val hs = HorizontalScrollView(this)
            hs.addView(row)
            hs
        }
    }

    private fun toolsItems(): List<Pair<String, () -> Unit>> {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items.add(toolEntry(Tool.ERASER, tr("🧹 Eraser", "ممحاة 🧹")))
        items.add(toolEntry(Tool.FILL, tr("💣 Fill", "تعبئة 💣")))
        items.add(toolEntry(Tool.PICKER, tr("🎨 Pick", "التقاط 🎨")))
        return items
    }

    private fun toolEntry(t: Tool, icon: String, name: String): Pair<String, () -> Unit> {
        val lbl = (if (pixelView.tool == t) "✓ " else "") + icon + " " + name
        return lbl to { selectTool(t) }
    }

    private fun openSettings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(4))

        // FEATURE 1: Language Toggle
        box.addView(label(tr("Language / اللغة", "اللغة / Language")))
        val langRow = LinearLayout(this)
        langRow.orientation = LinearLayout.HORIZONTAL
        val enBtn = makeButton("English") {
            appLanguage = "en"
            prefs.edit().putString("app_language", "en").apply()
            recreate()
        }
        val arBtn = makeButton("العربية") {
            appLanguage = "ar"
            prefs.edit().putString("app_language", "ar").apply()
            recreate()
        }
        if (appLanguage == "en") enBtn.setBackgroundColor(Color.rgb(70, 110, 200))
        else arBtn.setBackgroundColor(Color.rgb(70, 110, 200))
        langRow.addView(enBtn, LinearLayout.LayoutParams(0, btnH(), 1f))
        langRow.addView(arBtn, LinearLayout.LayoutParams(0, btnH(), 1f))
        box.addView(langRow)

        box.addView(label(tr("File app for Load / Paste PNG", "تطبيق الملفات للتحميل/اللصق")))
        val fileAppBtn = makeButton(fileAppLabel(prefs.getString("file_app", null))) {}
        fileAppBtn.setOnClickListener { chooseFileApp(-1) }
        box.addView(fileAppBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH()))

        val ghostCb = CheckBox(this)
        ghostCb.text = tr("👻 Ghost blocks preview", "معاينة الكتل الشبحية ")
        ghostCb.isChecked = pixelView.ghostN > 1
        box.addView(ghostCb)

        val ghostVal = label("")
        val ghostBar = SeekBar(this)
        ghostBar.max = 3
        if (pixelView.ghostN > 1) {
            ghostBar.progress = pixelView.ghostN - 2
            ghostVal.text = tr("Size: ", "الحجم: ") + pixelView.ghostN + "x" + pixelView.ghostN
        } else {
            ghostBar.progress = 1
            ghostVal.text = tr("Size: 3x3", "الحجم: 3x3")
        }
        box.addView(ghostVal)
        box.addView(ghostBar)

        ghostCb.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                pixelView.setGhost(ghostBar.progress + 2)
            } else {
                pixelView.setGhost(0)
            }
        }
        ghostBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + 2
                ghostVal.text = tr("Size: ", "الحجم: ") + n + "x" + n
                if (ghostCb.isChecked) {
                    pixelView.setGhost(n)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val brushVal = label("")
        val brushBar = SeekBar(this)
        brushBar.max = 2
        brushBar.progress = pixelView.brushSize - 1
        brushVal.text = tr("Pencil brush: ", "فرشاة القلم: ") + pixelView.brushSize + "x" + pixelView.brushSize
        box.addView(brushVal)
        box.addView(brushBar)
        brushBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + 1
                pixelView.brushSize = n
                brushVal.text = tr("Pencil brush: ", "فرشاة القلم: ") + n + "x" + n
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val eraserVal = label("")
        val eraserBar = SeekBar(this)
        eraserBar.max = 2
        eraserBar.progress = pixelView.eraserSize - 1
        eraserVal.text = tr("Eraser size: ", "حجم الممحاة: ") + pixelView.eraserSize + "x" + pixelView.eraserSize
        box.addView(eraserVal)
        box.addView(eraserBar)
        eraserBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + 1
                pixelView.eraserSize = n
                eraserVal.text = tr("Eraser size: ", "حجم الممحاة: ") + n + "x" + n
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val uiRow = LinearLayout(this)
        uiRow.orientation = LinearLayout.HORIZONTAL
        val uiLbl = label(tr("UI size:  ", "حجم الواجهة:  "))
        uiRow.addView(uiLbl)
        val sizeNames = arrayOf("S", "M", "L")
        for (i in 0..2) {
            val b = makeButton(sizeNames[i]) {}
            if (btnSize == i) {
                b.setBackgroundColor(Color.rgb(70, 110, 200))
            }
            b.setOnClickListener {
                setPref("btn_size", i)
            }
            val lp = LinearLayout.LayoutParams(dp(52), dp(40))
            lp.setMargins(dp(4), dp(6), dp(4), dp(6))
            uiRow.addView(b, lp)
        }
        box.addView(uiRow)
        AlertDialog.Builder(this)
            .setTitle(tr("Settings", "الإعدادات"))
            .setView(box)
            .setNegativeButton(tr("Close", "إغلاق"), null)
            .show()
    }

    private fun setPref(key: String, v: Int) {
        prefs.edit().putInt(key, v).apply()
        pixelView.stampSelection()
        stash = pixelView.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        recreate()
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        try {
            val tf = android.graphics.Typeface.createFromAsset(assets, "font/primary_font.ttf")
            b.typeface = tf
        } catch (e: Exception) {
        }
        b.isAllCaps = false
        b.textSize = 13f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(10), 0, dp(10), 0)
        b.setBackgroundColor(Color.rgb(60, 60, 60))
        b.setTextColor(Color.WHITE)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addButton(row: LinearLayout, label: String, vertical: Boolean = false, onClick: () -> Unit) {
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(makeButton(label, onClick), lp)
    }

    private fun addMenuButton(row: LinearLayout, label: String, items: List<Pair<String, () -> Unit>>, vertical: Boolean = false) {
        val b = makeButton(label) {}
        b.setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            for (i in items.indices) {
                pm.menu.add(0, i, i, items[i].first)
            }
            pm.setOnMenuItemClickListener { mi ->
                items[mi.itemId].second()
                true
            }
            pm.show()
        }
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addMenuButtonDynamic(row: LinearLayout, label: String, provider: () -> List<Pair<String, () -> Unit>>, vertical: Boolean) {
        val b = makeButton(label) {}
        b.setOnClickListener { v ->
            val list = provider()
            val pm = PopupMenu(this, v)
            for (i in list.indices) {
                pm.menu.add(0, i, i, list[i].first)
            }
            pm.setOnMenuItemClickListener { mi ->
                list[mi.itemId].second()
                true
            }
            pm.show()
        }
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addToolButton(row: LinearLayout, label: String, t: Tool, vertical: Boolean = false) {
        val b = makeButton(label) { selectTool(t) }
        toolButtons[t] = b
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun selectTool(t: Tool) {
        pixelView.tool = t
        for ((tool, btn) in toolButtons) {
            if (tool == t) {
                btn.setBackgroundColor(Color.rgb(70, 110, 200))
            } else {
                btn.setBackgroundColor(Color.rgb(60, 60, 60))
            }
        }
    }

    private fun setColor(c: Int) {
        val old = pixelView.currentColor
        if (old != c) {
            colorHistory.add(0, old)
            while (colorHistory.size > 12) {
                colorHistory.removeAt(colorHistory.size - 1)
            }
        }
        pixelView.currentColor = c
        colorChip.setBackgroundColor(c)
        updateHistoryViews()
    }

    private fun updateHistoryViews() {
        for (i in histViews.indices) {
            val hv = histViews[i]
            if (i < colorHistory.size) {
                hv.visibility = View.VISIBLE
                hv.setBackgroundColor(colorHistory[i])
            } else {
                hv.visibility = View.INVISIBLE
            }
        }
    }

    // FEATURE 4: Wand UI
    private lateinit var wandBtnRef: Button
    private lateinit var wandMenuRef: LinearLayout
    private lateinit var targetColorView: View
    private lateinit var replacerColorView: View

    private fun updateWandMenuVisibility() {
        if (colorPicker.wandMode) {
            wandBtnRef.setBackgroundColor(Color.rgb(70, 110, 200))
            wandBtnRef.text = tr("✓ Wand / Replace", "✓ عصا/استبدال")
            wandMenuRef.visibility = View.VISIBLE

            val target = colorPicker.getWandTargetColor()
            val replacer = colorPicker.getWandReplaceColor()

            if (target != null) {
                targetColorView.setBackgroundColor(target)
            } else {
                targetColorView.setBackgroundColor(Color.WHITE)
            }

            if (replacer != null) {
                replacerColorView.setBackgroundColor(replacer)
            } else {
                replacerColorView.setBackgroundColor(Color.WHITE)
            }
        } else {
            wandBtnRef.setBackgroundColor(Color.rgb(60, 60, 60))
            wandBtnRef.text = tr("Wand / Replace", "عصا/استبدال")
            wandMenuRef.visibility = View.GONE
        }
    }

    private fun openColors() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(4), dp(12), dp(4))

        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.gravity = Gravity.CENTER_VERTICAL
        histViews.clear()
        var dlg: AlertDialog? = null
        for (i in 0 until 5) {
            val hv = View(this)
            hv.setBackgroundColor(Color.WHITE)
            hv.setOnClickListener {
                if (i < colorHistory.size) {
                    setColor(colorHistory[i])
                    dlg?.dismiss()
                }
            }
            hv.setOnLongClickListener {
                if (i < colorHistory.size) showShades(colorHistory[i])
                true
            }
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            hrow.addView(hv, lp)
            histViews.add(hv)
        }
        box.addView(hrow)
        updateHistoryViews()

        val swrap = HorizontalScrollView(this)
        val srow = LinearLayout(this)
        srow.orientation = LinearLayout.HORIZONTAL
        srow.gravity = Gravity.CENTER_VERTICAL
        for (c in palette) {
            val sw = View(this)
            sw.setBackgroundColor(c)
            sw.setOnClickListener {
                setColor(c)
                dlg?.dismiss()
            }
            sw.setOnLongClickListener { showShades(c); true }
            val lp = LinearLayout.LayoutParams(dp(38), dp(38))
            lp.setMargins(dp(3), dp(6), dp(3), dp(6))
            srow.addView(sw, lp)
        }
        swrap.addView(srow)
        box.addView(swrap)

        // FEATURE 4: Wand Toggle & Menu
        wandBtnRef = makeButton(tr("Wand / Replace", "عصا/استبدال")) { colorPicker.toggleWandMode() }
        box.addView(wandBtnRef, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH()))

        wandMenuRef = LinearLayout(this)
        wandMenuRef.orientation = LinearLayout.VERTICAL
        wandMenuRef.setPadding(dp(8), dp(8), dp(8), dp(8))
        wandMenuRef.setBackgroundColor(Color.rgb(40, 40, 40))
        wandMenuRef.visibility = View.GONE

        val targetRow = LinearLayout(this)
        targetRow.orientation = LinearLayout.HORIZONTAL
        targetRow.gravity = Gravity.CENTER_VERTICAL
        val targetLabel = TextView(this)
        targetLabel.text = tr("Selected: ", "المحدد: ")
        targetLabel.setTextColor(Color.WHITE)
        targetRow.addView(targetLabel)
        targetColorView = View(this)
        targetColorView.setBackgroundColor(Color.WHITE)
        val targetLp = LinearLayout.LayoutParams(dp(32), dp(32))
        targetLp.setMargins(dp(8), 0, 0, 0)
        targetRow.addView(targetColorView, targetLp)
        wandMenuRef.addView(targetRow)

        val replacerRow = LinearLayout(this)
        replacerRow.orientation = LinearLayout.HORIZONTAL
        replacerRow.gravity = Gravity.CENTER_VERTICAL
        replacerRow.setPadding(0, dp(8), 0, 0)
        val replacerLabel = TextView(this)
        replacerLabel.text = tr("Replacer: ", "البديل: ")
        replacerLabel.setTextColor(Color.WHITE)
        replacerRow.addView(replacerLabel)
        replacerColorView = View(this)
        replacerColorView.setBackgroundColor(Color.WHITE)
        val replacerLp = LinearLayout.LayoutParams(dp(32), dp(32))
        replacerLp.setMargins(dp(8), 0, 0, 0)
        replacerRow.addView(replacerColorView, replacerLp)
        wandMenuRef.addView(replacerRow)

        val swapBtn = makeButton(tr("SWAP COLORS", "استبدال الألوان")) {
            val t = colorPicker.getWandTargetColor()
            val r = colorPicker.getWandReplaceColor()
            if (t != null && r != null) {
                colorPicker.onWandSwap?.invoke(t, r)
            }
        }
        swapBtn.setPadding(dp(10), dp(8), dp(10), dp(8))
        val swapLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        swapLp.setMargins(0, dp(12), 0, 0)
        wandMenuRef.addView(swapBtn, swapLp)
        box.addView(wandMenuRef)

        val hexBtn = makeButton("#  Hex") {
            dlg?.dismiss()
            askHex()
        }
        box.addView(hexBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH()))
        dlg = AlertDialog.Builder(this)
            .setTitle(tr("Colors", "الألوان"))
            .setView(box)
            .setNegativeButton(tr("Close", "إغلاق"), null)
            .create()
        dlg?.show()

        updateWandMenuVisibility()
    }

    // FEATURE 5: Smart Shade Picker
    private fun showShades(c: Int) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val scroll = HorizontalScrollView(this)
        scroll.addView(row)
        val dlg = AlertDialog.Builder(this)
            .setTitle(tr("Shades", "الدرجات"))
            .setView(scroll)
            .setNegativeButton(tr("Cancel", "إلغاء"), null)
            .create()

        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        val steps = listOf(-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50)

        for (step in steps) {
            val newV = (hsv[2] * (1f + step / 100f)).coerceIn(0.05f, 1f)
            val shadeColor = Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], newV))

            val sw = View(this)
            sw.setBackgroundColor(shadeColor)

            val luminance = (0.299 * Color.red(shadeColor) + 0.587 * Color.green(shadeColor) + 0.114 * Color.blue(shadeColor))
            val borderColor = if (luminance > 128) Color.BLACK else Color.WHITE

            val wrapper = LinearLayout(this)
            wrapper.setBackgroundColor(borderColor)
            val padding = if (step == 0) dp(4) else dp(2)
            wrapper.setPadding(padding, padding, padding, padding)

            wrapper.addView(sw, LinearLayout.LayoutParams(dp(34), dp(44)))

            sw.setOnClickListener { setColor(shadeColor); dlg.dismiss() }
            sw.setOnLongClickListener {
                Toast.makeText(this, "Brightness: ${step}%", Toast.LENGTH_SHORT).show()
                true
            }

            row.addView(wrapper, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(2), dp(6), dp(2), dp(6))
            })
        }
        dlg.show()
    }

    private fun numberBox(v: Int): EditText {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(v.toString())
        return e
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        return tv
    }

    private fun askSize(title: String, defW: Int, defH: Int, onOk: (Int, Int) -> Unit) {
        val wBox = numberBox(defW)
        val hBox = numberBox(defH)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(label(tr("Width (1-512)", "العرض (1-512)")))
        box.addView(wBox)
        box.addView(label(tr("Height (1-512)", "الارتفاع (1-512)")))
        box.addView(hBox)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val w = wBox.text.toString().toIntOrNull() ?: 0
                val h = hBox.text.toString().toIntOrNull() ?: 0
                if (w in 1..512 && h in 1..512) {
                    onOk(w, h)
                } else {
                    Toast.makeText(this, tr("Size must be 1 to 512", "يجب أن يكون الحجم بين 1 و 512"), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(tr("Cancel", "إلغاء"), null)
            .show()
    }

    private fun askHex() {
        val box = EditText(this)
        box.hint = "RRGGBB"
        AlertDialog.Builder(this)
            .setTitle("Hex color")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                try {
                    val s = box.text.toString().trim().removePrefix("#")
                    setColor(Color.parseColor("#" + s) or Color.BLACK)
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid color", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(tr("Cancel", "إلغاء"), null)
            .show()
    }

    private lateinit var resizePanel: LinearLayout
    private lateinit var rzWBox: EditText
    private lateinit var rzHBox: EditText
    private lateinit var rzWBar: SeekBar
    private lateinit var rzHBar: SeekBar
    private lateinit var rzWInfo: TextView
    private lateinit var rzHInfo: TextView
    private var rzOldW = 0
    private var rzOldH = 0
    private var rzNewW = 0
    private var rzNewH = 0
    private var rzL = 0
    private var rzT = 0
    private var rzUpdating = false
    private var rzPrevTool = Tool.PENCIL

    private fun watcher(onChange: () -> Unit): android.text.TextWatcher {
        return object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                onChange()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        }
    }

    private fun buildResizePanel(): LinearLayout {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(Color.rgb(36, 36, 36))
        panel.setPadding(dp(10), dp(4), dp(10), dp(6))
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label(tr("Resize canvas (red=cut, green=add)", "تغيير الحجم (أحمر=قص، أخضر=إضافة)"))
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(makeButton(tr("Cancel", "إلغاء")) { closeResizePanel() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        head.addView(makeButton(tr("Apply", "تطبيق")) { applyResize() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        panel.addView(head)
        rzWBox = numberBox(16)
        rzHBox = numberBox(16)
        rzWBar = SeekBar(this)
        rzHBar = SeekBar(this)
        rzWInfo = label("")
        rzHInfo = label("")
        rzWInfo.textSize = 12f
        rzHInfo.textSize = 12f
        panel.addView(resizeRow(tr("Width", "العرض"), rzWBox, rzWBar))
        panel.addView(rzWInfo)
        panel.addView(resizeRow(tr("Height", "الارتفاع"), rzHBox, rzHBar))
        panel.addView(rzHInfo)
        rzWBox.addTextChangedListener(watcher { onResizeInput(true) })
        rzHBox.addTextChangedListener(watcher { onResizeInput(false) })
        val barListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    rzL = rzWBar.progress
                    rzT = rzHBar.progress
                    updateResizePreview()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        rzWBar.setOnSeekBarChangeListener(barListener)
        rzHBar.setOnSeekBarChangeListener(barListener)
        return panel
    }

    private fun resizeRow(name: String, box: EditText, bar: SeekBar): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(label(name + " → "))
        row.addView(box, LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(bar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    private fun openResizePanel() {
        pixelView.stampSelection()
        rzOldW = pixelView.bitmap.width
        rzOldH = pixelView.bitmap.height
        rzNewW = rzOldW
        rzNewH = rzOldH
        rzL = 0
        rzT = 0
        rzUpdating = true
        rzWBox.setText(rzOldW.toString())
        rzHBox.setText(rzOldH.toString())
        rzWBar.max = 0
        rzHBar.max = 0
        rzWBar.progress = 0
        rzHBar.progress = 0
        rzUpdating = false
        if (resizePanel.visibility != View.VISIBLE) {
            rzPrevTool = pixelView.tool
        }
        resizePanel.visibility = View.VISIBLE
        selectTool(Tool.HAND)
        updateResizePreview()
    }

    private fun onResizeInput(isWidth: Boolean) {
        if (rzUpdating) return
        rzUpdating = true
        if (isWidth) {
            val v = rzWBox.text.toString().toIntOrNull()
            rzNewW = if (v != null && v in 1..512) v else rzOldW
            rzWBar.max = Math.abs(rzNewW - rzOldW)
            rzL = rzWBar.max / 2
            rzWBar.progress = rzL
        } else {
            val v = rzHBox.text.toString().toIntOrNull()
            rzNewH = if (v != null && v in 1..512) v else rzOldH
            rzHBar.max = Math.abs(rzNewH - rzOldH)
            rzT = rzHBar.max / 2
            rzHBar.progress = rzT
        }
        rzUpdating = false
        updateResizePreview()
    }

    private fun axisInfo(first: String, second: String, d: Int, amount: Int): String {
        if (d == 0) return tr("No change", "لا تغيير")
        val n = Math.abs(d)
        val verb = if (d < 0) tr("Cut ", "قص ") else tr("Add ", "إضافة ")
        return verb + n + ": " + first + " " + amount + " • " + second + " " + (n - amount)
    }

    private fun updateResizePreview() {
        val dw = rzNewW - rzOldW
        val dh = rzNewH - rzOldH
        val offX = if (dw < 0) rzL else -rzL
        val offY = if (dh < 0) rzT else -rzT
        pixelView.setResizePreview(rzNewW, rzNewH, offX, offY)
        rzWInfo.text = axisInfo(tr("Left", "يسار"), tr("Right", "يمين"), dw, rzL)
        rzHInfo.text = axisInfo(tr("Top", "أعلى"), tr("Bottom", "أسفل"), dh, rzT)
    }

    private fun applyResize() {
        val dw = rzNewW - rzOldW
        val dh = rzNewH - rzOldH
        val offX = if (dw < 0) rzL else -rzL
        val offY = if (dh < 0) rzT else -rzT
        if (dw != 0 || dh != 0) {
            pixelView.resizeCanvasAnchored(rzNewW, rzNewH, offX, offY)
        }
        closeResizePanel()
    }

    private fun closeResizePanel() {
        pixelView.clearResizePreview()
        resizePanel.visibility = View.GONE
        selectTool(rzPrevTool)
    }

    private fun fileAppLabel(pkg: String?): String {
        if (pkg == null) return tr("Not chosen yet - tap to choose", "لم يتم الاختيار - انقر")
        if (pkg == "system") return tr("Android file browser", "متصفح ملفات أندرويد")
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    private fun fileAppHandlers(): List<Pair<String, String>> {
        val probe = Intent(Intent.ACTION_GET_CONTENT)
        probe.addCategory(Intent.CATEGORY_OPENABLE)
        probe.type = "*/*"
        val out = ArrayList<Pair<String, String>>()
        val seen = HashSet<String>()
        for (ri in packageManager.queryIntentActivities(probe, 0)) {
            val pkg = ri.activityInfo.packageName
            if (seen.add(pkg)) {
                out.add(Pair(pkg, ri.loadLabel(packageManager).toString()))
            }
        }
        return out
    }

    private fun autoPickApp(): String? {
        for (h in fileAppHandlers()) {
            if (h.first.startsWith("bin.mt.plus")) {
                prefs.edit().putString("file_app", h.first).apply()
                return h.first
            }
        }
        return null
    }

    private fun pickImage(req: Int) {
        val saved = prefs.getString("file_app", null)
        val app: String = saved ?: autoPickApp() ?: run {
            chooseFileApp(req)
            return
        }
        launchPicker(req, app)
    }

    private fun launchPicker(req: Int, app: String) {
        try {
            if (app == "system") {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "image/*"
                startActivityForResult(i, req)
            } else {
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                i.setPackage(app)
                startActivityForResult(i, req)
            }
        } catch (e: Exception) {
            Toast.makeText(this, tr("That file app could not open. Pick another one.", "تعذر فتح التطبيق. اختر آخر."), Toast.LENGTH_LONG).show()
            chooseFileApp(req)
        }
    }

    private fun chooseFileApp(req: Int) {
        val pkgs = ArrayList<String>()
        val labels = ArrayList<String>()
        pkgs.add("system")
        labels.add(tr("Android file browser", "متصفح ملفات أندرويد"))
        for (h in fileAppHandlers()) {
            pkgs.add(h.first)
            labels.add(h.second)
        }
        AlertDialog.Builder(this)
            .setTitle(tr("Pick your file app", "اختر تطبيق الملفات"))
            .setItems(labels.toTypedArray()) { _, which ->
                prefs.edit().putString("file_app", pkgs[which]).apply()
                Toast.makeText(this, tr("File app: ", "تطبيق الملفات: ") + fileAppLabel(pkgs[which]), Toast.LENGTH_SHORT).show()
                if (req >= 0) launchPicker(req, pkgs[which])
            }
            .setNegativeButton(tr("Cancel", "إلغاء"), null)
            .show()
    }

    private fun snapToast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    private fun snapDir(): java.io.File {
        val d = java.io.File(filesDir, "snapshots")
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun snapFiles(): List<java.io.File> {
        val list = snapDir().listFiles()
        if (list == null) return emptyList()
        return list.filter { it.name.endsWith(".png") }.sortedByDescending { it.name }
    }

    private fun nameFile(f: java.io.File): java.io.File {
        return java.io.File(f.parentFile, f.name.removeSuffix(".png") + ".txt")
    }

    private fun snapName(f: java.io.File): String {
        val nf = nameFile(f)
        if (!nf.exists()) return ""
        return try {
            nf.readText().trim()
        } catch (e: Exception) {
            ""
        }
    }

    private fun setSnapName(f: java.io.File, name: String) {
        val nf = nameFile(f)
        val clean = name.trim()
        try {
            if (clean.isEmpty()) {
                nf.delete()
            } else {
                nf.writeText(clean)
            }
        } catch (e: Exception) {
            snapToast(tr("Could not save the name", "تعذر حفظ الاسم"))
        }
    }

    private fun deleteSnap(f: java.io.File) {
        nameFile(f).delete()
        f.delete()
    }

    private fun snapLabel(f: java.io.File): String {
        val ms = f.name.removePrefix("s_").removeSuffix(".png").toLongOrNull() ?: f.lastModified()
        val t = java.text.SimpleDateFormat("h:mm a", java.util.Locale.ENGLISH).format(java.util.Date(ms))
        val name = snapName(f)
        if (name.isEmpty()) return t
        return name + "  •  " + t
    }

    private fun snapItems(): List<Pair<String, () -> Unit>> {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items.add(tr("📸 Save snapshot", "حفظ لقطة 📸") to { saveSnapshot() })
        val files = snapFiles()
        var n = 0
        for (f in files) {
            if (n >= 5) break
            items.add("↩ " + snapLabel(f) to { restoreSnapshot(f) })
            n++
        }
        if (files.isNotEmpty()) {
            items.add(tr("👁 Compare…", "مقارنة 👁…") to { pickSnapshot(tr("Compare with", "مقارنة مع")) { f -> startCompare(f) } })
            items.add(tr("✏ Rename…", "إعادة تسمية ✏…") to { pickSnapshot(tr("Rename which?", "إعادة تسمية أي؟")) { f -> renameSnapshot(f) } })
            items.add(tr("🗑 Delete…", "حذف 🗑…") to { pickSnapshot(tr("Delete which?", "حذف أي؟")) { f -> deleteSnap(f) } })
        }
        if (pixelView.compareBitmap != null) {
            items.add(tr("✖ Stop compare", "إيقاف المقارنة ✖") to { pixelView.compareBitmap = null })
        }
        return items
    }

    private fun saveSnapshot() {
        pixelView.stampSelection()
        val box = EditText(this)
        box.hint = tr("Name (optional)", "الاسم (اختياري)")
        box.isSingleLine = true
        AlertDialog.Builder(this)
            .setTitle(tr("Save snapshot", "حفظ لقطة"))
            .setView(box)
            .setPositiveButton(tr("Save", "حفظ")) { _, _ -> writeSnapshot(box.text.toString()) }
            .setNegativeButton(tr("Cancel", "إلغاء"), null)
            .show()
    }

    private fun writeSnapshot(name: String) {
        val f = java.io.File(snapDir(), "s_" + System.currentTimeMillis() + ".png")
        try {
            val out = java.io.FileOutputStream(f)
            pixelView.bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.close()
        } catch (e: Exception) {
            snapToast(tr("Could not save snapshot", "تعذر حفظ اللقطة"))
            return
        }
        setSnapName(f, name)
        val all = snapFiles()
        for (i in 12 until all.size) {
            deleteSnap(all[i])
        }
        snapToast(tr("Snapshot saved", "تم حفظ اللقطة"))
    }

    private fun renameSnapshot(f: java.io.File) {
        val box = EditText(this)
        box.setText(snapName(f))
        box.isSingleLine = true
        AlertDialog.Builder(this)
            .setTitle(tr("Rename snapshot", "إعادة تسمية اللقطة"))
            .setView(box)
            .setPositiveButton("OK") { _, _ -> setSnapName(f, box.text.toString()) }
            .setNegativeButton(tr("Cancel", "إلغاء"), null)
            .show()
    }

    private fun restoreSnapshot(f: java.io.File) {
        val b = BitmapFactory.decodeFile(f.absolutePath)
        if (b == null) {
            snapToast(tr("Could not read snapshot", "تعذر قراءة اللقطة"))
            return
        }
        pixelView.replaceWith(b)
        Toast.makeText(this, tr("Restored. Undo brings your current work back.", "تم الاستعادة. التراجع يعيد عملك."), Toast.LENGTH_LONG).show()
    }

    private fun startCompare(f: java.io.File) {
        val b = BitmapFactory.decodeFile(f.absolutePath)
        if (b == null) {
            snapToast(tr("Could not read snapshot", "تعذر قراءة اللقطة"))
            return
        }
        pixelView.compareBitmap = b
        Toast.makeText(this, tr("Snapshot shown over your work.", "تظهر اللقطة فوق عملك."), Toast.LENGTH_LONG).show()
    }

    private fun pickSnapshot(title: String, onPick: (java.io.File) -> Unit) {
        val files = snapFiles()
        if (files.isEmpty()) {
            snapToast(tr("No snapshots yet", "لا توجد لقطات"))
            return
        }
        val labels = Array(files.size) { snapLabel(files[it]) }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels) { _, which -> onPick(files[which]) }
            .show()
    }

    private fun saveImage() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_TITLE, "pixel.png")
        startActivityForResult(i, reqSave)
    }

    private fun decode(uri: Uri): Bitmap? {
        var bmp: Bitmap? = null
        try {
            val stream = contentResolver.openInputStream(uri)
            if (stream != null) {
                val o = BitmapFactory.Options()
                o.inScaled = false
                o.inPreferredConfig = Bitmap.Config.ARGB_8888
                bmp = BitmapFactory.decodeStream(stream, null, o)
                stream.close()
            }
        } catch (e: Exception) {
            bmp = null
        }
        if (bmp == null) {
            Toast.makeText(this, tr("Could not open image", "تعذر فتح الصورة"), Toast.LENGTH_SHORT).show()
            return null
        }
        if (bmp.width > 1024 || bmp.height > 1024) {
            Toast.makeText(this, tr("Image too big (max 1024x1024)", "الصورة كبيرة جداً (1024x1024)"), Toast.LENGTH_SHORT).show()
            return null
        }
        return bmp
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        if (requestCode == reqLoad) {
            val b = decode(uri)
            if (b != null) pixelView.loadBitmap(b)
        } else if (requestCode == reqPaste) {
            val b = decode(uri)
            if (b != null) {
                pixelView.beginPaste(b)
                selectTool(Tool.SELECT)
            }
        } else if (requestCode == reqSave) {
            try {
                val out = contentResolver.openOutputStream(uri)
                if (out != null) {
                    pixelView.bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.close()
                    Toast.makeText(this, tr("Saved", "تم الحفظ"), Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, tr("Save failed", "فشل الحفظ"), Toast.LENGTH_SHORT).show()
            }
        }
    }
}