package com.pixelpack.editor

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        var stash: Bitmap? = null
    }

    private lateinit var pixelView: PixelView
    private lateinit var colorChip: View
    private lateinit var prefs: SharedPreferences
    private val toolButtons = LinkedHashMap<Tool, Button>()

    private var btnSize = 1
    private var barPos = 0
    private var barVertical = false

    private val reqLoad = 1
    private val reqSave = 2
    private val reqPaste = 3

    private val colorHistory = mutableListOf<Int>()
    private val histViews = ArrayList<View>()

    private val palette = intArrayOf(
        Color.rgb(0, 0, 0), Color.rgb(255, 255, 255), Color.rgb(127, 127, 127), Color.rgb(195, 195, 195),
        Color.rgb(136, 0, 21), Color.rgb(237, 28, 36), Color.rgb(255, 127, 39), Color.rgb(255, 242, 0),
        Color.rgb(34, 177, 76), Color.rgb(0, 162, 232), Color.rgb(63, 72, 204), Color.rgb(163, 73, 164),
        Color.rgb(185, 122, 87), Color.rgb(255, 174, 201), Color.rgb(255, 201, 14), Color.rgb(153, 217, 234)
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun btnH(): Int = dp(when (btnSize) { 0 -> 36; 2 -> 54; else -> 44 })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getPreferences(Context.MODE_PRIVATE)
        btnSize = prefs.getInt("btn_size", 1)
        barPos = prefs.getInt("bar_pos", 0)
        barVertical = barPos == 2

        pixelView = PixelView(this)
        colorChip = View(this)
        colorChip.setOnClickListener { showShades(pixelView.currentColor) }

        val content = LinearLayout(this)
        content.setBackgroundColor(Color.rgb(24, 24, 24))

        val toolbarView = buildToolbar()
        if (barVertical) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(pixelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            content.orientation = LinearLayout.HORIZONTAL
            content.addView(toolbarView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            content.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        } else {
            content.orientation = LinearLayout.VERTICAL
            if (barPos == 1) content.addView(toolbarView)
            content.addView(pixelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            if (barPos == 0) content.addView(toolbarView)
        }

        // floating settings cog, upper right corner
        val root = FrameLayout(this)
        root.fitsSystemWindows = true
        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val cog = makeButton("\u2699") {}
        cog.textSize = 26f
        cog.setOnClickListener { openSettings() }
        val clp = FrameLayout.LayoutParams(dp(54), dp(54), Gravity.TOP or Gravity.END)
        val cogTop: Int
        if (barPos == 1) {
            cogTop = dp(8) + btnH() + dp(4)
        } else {
            cogTop = dp(8)
        }
        clp.setMargins(dp(8), cogTop, dp(8), dp(8))
        root.addView(cog, clp)
        setContentView(root)

        val s = stash
        if (s != null) {
            stash = null
            pixelView.loadBitmap(s)
        }

        pixelView.onColorPicked = { c ->
            setColor(c)
            selectTool(Tool.PENCIL)
        }
        setColor(Color.BLACK)
        selectTool(Tool.PENCIL)

        if (savedInstanceState == null) handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    // image opened from another app (file manager "Open with" or Share)
    private fun handleIncoming(intent: Intent?) {
        if (intent == null) return
        var uri: Uri? = null
        if (intent.action == Intent.ACTION_VIEW) {
            uri = intent.data
        } else if (intent.action == Intent.ACTION_SEND) {
            uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
        if (uri == null) return
        val u: Uri = uri
        val b = decode(u) ?: return
        AlertDialog.Builder(this)
            .setTitle("Open image")
            .setMessage("What do you want to do with it?")
            .setPositiveButton("Open as new canvas") { _, _ -> pixelView.loadBitmap(b) }
            .setNeutralButton("Paste onto canvas") { _, _ -> pixelView.beginPaste(b) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- UI building ----------

    private fun buildToolbar(): View {
        val row = LinearLayout(this)
        row.orientation = if (barVertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL

        val chipLp = LinearLayout.LayoutParams(dp(34), dp(34))
        chipLp.setMargins(dp(4), dp(4), dp(4), dp(4))
        row.addView(colorChip, chipLp)

        addToolButton(row, "\u270f\ufe0f Pencil", Tool.PENCIL, barVertical)
        addMenuButtonDynamic(row, "\uD83D\uDCE0 Tools", { toolsItems() }, barVertical)
        addToolButton(row, "\u25e7 Select", Tool.SELECT, barVertical)
        addToolButton(row, "\u270b Hand", Tool.HAND, barVertical)
        addButton(row, "\u21b6 Undo", barVertical) { pixelView.undo() }
        addButton(row, "\u21b7 Redo", barVertical) { pixelView.redo() }
        addMenuButtonDynamic(row, "\uD83D\uDD16 Snap", { snapItems() }, barVertical)
        addButton(row, "\u229e Grid", barVertical) { pixelView.showGrid = !pixelView.showGrid }
        addButton(row, "\uD83C\uDFA8 Colors", barVertical) { openColors() }
        addMenuButton(
            row, "\uD83D\uDCC1 File", listOf(
                "\uD83D\uDCBE Save PNG" to { saveImage() },
                "\uD83D\uDCC2 Load PNG" to { pickImage(reqLoad) },
                "\uD83D\uDCC2 Load PNG (other app\u2026)" to { pickImage(reqLoad, true) },
                "\uD83D\uDCE5 Paste PNG" to { pickImage(reqPaste) },
                "\uD83D\uDCE5 Paste PNG (other app\u2026)" to { pickImage(reqPaste, true) }
            ), barVertical
        )
        addMenuButton(
            row, "\uD83D\uDDBC Canvas", listOf(
                "\uD83C\uDD95 New\u2026" to {
                    askSize("New canvas", 32, 32) { w, h -> pixelView.newCanvas(w, h) }
                },
                "\u2194\ufe0f Resize\u2026" to {
                    askSize("Resize canvas", pixelView.bitmap.width, pixelView.bitmap.height) { w, h ->
                        pixelView.resizeCanvas(w, h)
                    }
                },
                "\u2b1c Clear (transparent)" to { pixelView.clearCanvas() },
                "\uD83D\uDD8C Fill background" to { pixelView.fillBackground(pixelView.currentColor) }
            ), barVertical
        )

        return if (barVertical) {
            val sv = ScrollView(this)
            sv.addView(row)
            sv
        } else {
            val hs = HorizontalScrollView(this)
            hs.addView(row)
            hs
        }
    }

    private fun toolsItems(): List<Pair<String, () -> Unit>> {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items.add(toolEntry(Tool.ERASER, "\uD83E\uDE79", "Eraser"))
        items.add(toolEntry(Tool.FILL, "\uD83E\uDCA3", "Fill"))
        items.add(toolEntry(Tool.PICKER, "\uD83C\uDFA8", "Pick"))
        items.add(toolEntry(Tool.WAND, "\uD83E\uDE84", "Wand (same color)"))

        val dLabel: String
        if (pixelView.dither) { dLabel = "\u2713 Dither: ON" } else { dLabel = "Dither: off" }
        items.add(dLabel to { pixelView.dither = !pixelView.dither })

        items.add("\uD83D\uDD01 Swap color\u2026" to {
            pixelView.requestSwap()
            Toast.makeText(this, "Tap a pixel of the color to replace everywhere", Toast.LENGTH_LONG).show()
        })
        return items
    }

    private fun toolEntry(t: Tool, icon: String, name: String): Pair<String, () -> Unit> {
        val lbl = (if (pixelView.tool == t) "\u2713 " else "") + icon + " " + name
        return lbl to { selectTool(t) }
    }

    // ---------- settings panel ----------

    private fun openSettings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(4))

        // ghost blocks preview: checkbox + size slider
        val ghostCb = CheckBox(this)
        ghostCb.text = "\uD83D\uDC7B Ghost blocks preview"
        ghostCb.isChecked = pixelView.ghostN > 1
        box.addView(ghostCb)

        val ghostVal = label("")
        val ghostBar = SeekBar(this)
        ghostBar.max = 3
        if (pixelView.ghostN > 1) {
            ghostBar.progress = pixelView.ghostN - 2
            ghostVal.text = "Size: " + pixelView.ghostN + "x" + pixelView.ghostN
        } else {
            ghostBar.progress = 1
            ghostVal.text = "Size: 3x3"
        }
        box.addView(ghostVal)
        box.addView(ghostBar)

        ghostCb.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                pixelView.setGhost(ghostBar.progress + 2)
            } else {
                pixelView.setGhost(0)
            }
        }
        ghostBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + 2
                ghostVal.text = "Size: " + n + "x" + n
                if (ghostCb.isChecked) {
                    pixelView.setGhost(n)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // pencil brush slider
        val brushVal = label("")
        val brushBar = SeekBar(this)
        brushBar.max = 2
        brushBar.progress = pixelView.brushSize - 1
        brushVal.text = "Pencil brush: " + pixelView.brushSize + "x" + pixelView.brushSize
        box.addView(brushVal)
        box.addView(brushBar)
        brushBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + 1
                pixelView.brushSize = n
                brushVal.text = "Pencil brush: " + n + "x" + n
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // eraser size slider
        val eraserVal = label("")
        val eraserBar = SeekBar(this)
        eraserBar.max = 2
        eraserBar.progress = pixelView.eraserSize - 1
        eraserVal.text = "Eraser size: " + pixelView.eraserSize + "x" + pixelView.eraserSize
        box.addView(eraserVal)
        box.addView(eraserBar)
        eraserBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + 1
                pixelView.eraserSize = n
                eraserVal.text = "Eraser size: " + n + "x" + n
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // UI size row
        val uiRow = LinearLayout(this)
        uiRow.orientation = LinearLayout.HORIZONTAL
        val uiLbl = label("UI size:  ")
        uiRow.addView(uiLbl)
        val sizeNames = arrayOf("S", "M", "L")
        for (i in 0..2) {
            val b = makeButton(sizeNames[i]) {}
            if (btnSize == i) {
                b.setBackgroundColor(Color.rgb(70, 110, 200))
            }
            b.setOnClickListener {
                setPref("btn_size", i)
            }
            val lp = LinearLayout.LayoutParams(dp(52), dp(40))
            lp.setMargins(dp(4), dp(6), dp(4), dp(6))
            uiRow.addView(b, lp)
        }
        box.addView(uiRow)

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(box)
            .setNegativeButton("Close", null)
            .show()
    }

    private fun setPref(key: String, v: Int) {
        prefs.edit().putInt(key, v).apply()
        pixelView.stampSelection()
        stash = pixelView.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        recreate()
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 13f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(10), 0, dp(10), 0)
        b.setBackgroundColor(Color.rgb(60, 60, 60))
        b.setTextColor(Color.WHITE)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addButton(row: LinearLayout, label: String, vertical: Boolean = false, onClick: () -> Unit) {
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(makeButton(label, onClick), lp)
    }

    private fun addMenuButton(row: LinearLayout, label: String, items: List<Pair<String, () -> Unit>>, vertical: Boolean = false) {
        val b = makeButton(label) {}
        b.setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            for (i in items.indices) {
                pm.menu.add(0, i, i, items[i].first)
            }
            pm.setOnMenuItemClickListener { mi ->
                items[mi.itemId].second()
                true
            }
            pm.show()
        }
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addMenuButtonDynamic(row: LinearLayout, label: String, provider: () -> List<Pair<String, () -> Unit>>, vertical: Boolean) {
        val b = makeButton(label) {}
        b.setOnClickListener { v ->
            val list = provider()
            val pm = PopupMenu(this, v)
            for (i in list.indices) {
                pm.menu.add(0, i, i, list[i].first)
            }
            pm.setOnMenuItemClickListener { mi ->
                list[mi.itemId].second()
                true
            }
            pm.show()
        }
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addToolButton(row: LinearLayout, label: String, t: Tool, vertical: Boolean = false) {
        val b = makeButton(label) { selectTool(t) }
        toolButtons[t] = b
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun selectTool(t: Tool) {
        pixelView.tool = t
        for ((tool, btn) in toolButtons) {
            if (tool == t) {
                btn.setBackgroundColor(Color.rgb(70, 110, 200))
            } else {
                btn.setBackgroundColor(Color.rgb(60, 60, 60))
            }
        }
    }

    private fun setColor(c: Int) {
        val old = pixelView.currentColor
        if (old != c) {
            colorHistory.add(0, old)
            while (colorHistory.size > 5) {
                colorHistory.removeAt(colorHistory.size - 1)
            }
        }
        pixelView.currentColor = c
        colorChip.setBackgroundColor(c)
        updateHistoryViews()
    }

    private fun updateHistoryViews() {
        for (i in histViews.indices) {
            val hv = histViews[i]
            if (i < colorHistory.size) {
                hv.visibility = View.VISIBLE
                hv.setBackgroundColor(colorHistory[i])
            } else {
                hv.visibility = View.INVISIBLE
            }
        }
    }

    // ---------- colors window ----------

    private fun openColors() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(4), dp(12), dp(4))

        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.gravity = Gravity.CENTER_VERTICAL
        histViews.clear()
        var dlg: AlertDialog? = null
        for (i in 0 until 5) {
            val hv = View(this)
            hv.setBackgroundColor(Color.WHITE)
            hv.setOnClickListener {
                if (i < colorHistory.size) {
                    setColor(colorHistory[i])
                    dlg?.dismiss()
                }
            }
            hv.setOnLongClickListener {
                if (i < colorHistory.size) showShades(colorHistory[i])
                true
            }
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            hrow.addView(hv, lp)
            histViews.add(hv)
        }
        box.addView(hrow)
        updateHistoryViews()

        val swrap = HorizontalScrollView(this)
        val srow = LinearLayout(this)
        srow.orientation = LinearLayout.HORIZONTAL
        srow.gravity = Gravity.CENTER_VERTICAL
        for (c in palette) {
            val sw = View(this)
            sw.setBackgroundColor(c)
            sw.setOnClickListener {
                setColor(c)
                dlg?.dismiss()
            }
            sw.setOnLongClickListener { showShades(c); true }
            val lp = LinearLayout.LayoutParams(dp(38), dp(38))
            lp.setMargins(dp(3), dp(6), dp(3), dp(6))
            srow.addView(sw, lp)
        }
        swrap.addView(srow)
        box.addView(swrap)

        val hexBtn = makeButton("#  Hex") {
            dlg?.dismiss()
            askHex()
        }
        box.addView(hexBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH()))

        dlg = AlertDialog.Builder(this)
            .setTitle("Colors")
            .setView(box)
            .setNegativeButton("Close", null)
            .create()
        dlg?.show()
    }

    // ---------- shade picker ----------

    private fun shadesOf(c: Int, steps: Int = 5): IntArray {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        val out = IntArray(steps * 2 + 1)
        for (i in -steps..steps) {
            val v = (hsv[2] * (1f + 0.13f * i)).coerceIn(0.02f, 1f)
            out[i + steps] = Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], v))
        }
        return out
    }

    private fun showShades(c: Int) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val scroll = HorizontalScrollView(this)
        scroll.addView(row)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Shades")
            .setView(scroll)
            .setNegativeButton("Cancel", null)
            .create()
        for (s in shadesOf(c)) {
            val sw = View(this)
            sw.setBackgroundColor(s)
            sw.setOnClickListener {
                setColor(s)
                dlg.dismiss()
            }
            val lp = LinearLayout.LayoutParams(dp(34), dp(44))
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            row.addView(sw, lp)
        }
        dlg.show()
    }

    // ---------- dialogs ----------

    private fun numberBox(v: Int): EditText {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(v.toString())
        return e
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        return tv
    }

    private fun askSize(title: String, defW: Int, defH: Int, onOk: (Int, Int) -> Unit) {
        val wBox = numberBox(defW)
        val hBox = numberBox(defH)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(label("Width (1-512)"))
        box.addView(wBox)
        box.addView(label("Height (1-512)"))
        box.addView(hBox)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val w = wBox.text.toString().toIntOrNull() ?: 0
                val h = hBox.text.toString().toIntOrNull() ?: 0
                if (w in 1..512 && h in 1..512) {
                    onOk(w, h)
                } else {
                    Toast.makeText(this, "Size must be 1 to 512", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askHex() {
        val box = EditText(this)
        box.hint = "RRGGBB"
        AlertDialog.Builder(this)
            .setTitle("Hex color")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                try {
                    val s = box.text.toString().trim().removePrefix("#")
                    setColor(Color.parseColor("#" + s) or Color.BLACK)
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid color", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- files ----------

    // otherApp = false: Android's file browser (lists file apps such as MT Manager in its side menu, no gallery apps)
    // otherApp = true: chooser of any app that can hand over a file
    private fun pickImage(req: Int, otherApp: Boolean = false) {
        try {
            if (otherApp) {
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                startActivityForResult(Intent.createChooser(i, "Open with"), req)
            } else {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "image/*"
                startActivityForResult(i, req)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "No app found to pick a file", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- snapshots ----------

    private fun snapToast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    private fun snapDir(): java.io.File {
        val d = java.io.File(filesDir, "snapshots")
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun snapFiles(): List<java.io.File> {
        val list = snapDir().listFiles()
        if (list == null) return emptyList()
        return list.filter { it.name.endsWith(".png") }.sortedByDescending { it.name }
    }

    private fun snapLabel(f: java.io.File): String {
        val ms = f.name.removePrefix("s_").removeSuffix(".png").toLongOrNull() ?: f.lastModified()
        val t = java.text.SimpleDateFormat("MMM d, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ms))
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.absolutePath, o)
        return t + "  (" + o.outWidth + "x" + o.outHeight + ")"
    }

    private fun snapItems(): List<Pair<String, () -> Unit>> {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items.add("\uD83D\uDCF8 Save snapshot" to { saveSnapshot() })
        val files = snapFiles()
        var n = 0
        for (f in files) {
            if (n >= 5) break
            items.add("\u21a9 " + snapLabel(f) to { restoreSnapshot(f) })
            n++
        }
        if (files.isNotEmpty()) {
            items.add("\uD83D\uDC41 Compare\u2026" to { pickSnapshot("Compare with") { f -> startCompare(f) } })
            items.add("\uD83D\uDDD1 Delete\u2026" to { pickSnapshot("Delete which?") { f -> f.delete() } })
        }
        if (pixelView.compareBitmap != null) {
            items.add("\u2716 Stop compare" to { pixelView.compareBitmap = null })
        }
        return items
    }

    private fun saveSnapshot() {
        pixelView.stampSelection()
        val f = java.io.File(snapDir(), "s_" + System.currentTimeMillis() + ".png")
        try {
            val out = java.io.FileOutputStream(f)
            pixelView.bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.close()
        } catch (e: Exception) {
            snapToast("Could not save snapshot")
            return
        }
        val all = snapFiles()
        for (i in 12 until all.size) {
            all[i].delete()
        }
        snapToast("Snapshot saved")
    }

    private fun restoreSnapshot(f: java.io.File) {
        val b = BitmapFactory.decodeFile(f.absolutePath)
        if (b == null) {
            snapToast("Could not read snapshot")
            return
        }
        pixelView.replaceWith(b)
        Toast.makeText(this, "Restored. Undo brings your current work back.", Toast.LENGTH_LONG).show()
    }

    private fun startCompare(f: java.io.File) {
        val b = BitmapFactory.decodeFile(f.absolutePath)
        if (b == null) {
            snapToast("Could not read snapshot")
            return
        }
        pixelView.compareBitmap = b
        Toast.makeText(this, "Snapshot shown over your work. Snap > Stop compare hides it.", Toast.LENGTH_LONG).show()
    }

    private fun pickSnapshot(title: String, onPick: (java.io.File) -> Unit) {
        val files = snapFiles()
        if (files.isEmpty()) {
            snapToast("No snapshots yet")
            return
        }
        val labels = Array(files.size) { snapLabel(files[it]) }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels) { _, which -> onPick(files[which]) }
            .show()
    }

    private fun saveImage() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_TITLE, "pixel.png")
        startActivityForResult(i, reqSave)
    }

    private fun decode(uri: Uri): Bitmap? {
        var bmp: Bitmap? = null
        try {
            val stream = contentResolver.openInputStream(uri)
            if (stream != null) {
                val o = BitmapFactory.Options()
                o.inScaled = false
                o.inPreferredConfig = Bitmap.Config.ARGB_8888
                bmp = BitmapFactory.decodeStream(stream, null, o)
                stream.close()
            }
        } catch (e: Exception) {
            bmp = null
        }
        if (bmp == null) {
            Toast.makeText(this, "Could not open image", Toast.LENGTH_SHORT).show()
            return null
        }
        if (bmp.width > 1024 || bmp.height > 1024) {
            Toast.makeText(this, "Image too big (max 1024x1024)", Toast.LENGTH_SHORT).show()
            return null
        }
        return bmp
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        if (requestCode == reqLoad) {
            val b = decode(uri)
            if (b != null) pixelView.loadBitmap(b)
        } else if (requestCode == reqPaste) {
            val b = decode(uri)
            if (b != null) pixelView.beginPaste(b)
        } else if (requestCode == reqSave) {
            try {
                val out = contentResolver.openOutputStream(uri)
                if (out != null) {
                    pixelView.bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.close()
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
