package com.pixelpack.editor

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        var stash: Bitmap? = null
    }

    private lateinit var pixelView: PixelView
    private lateinit var colorChip: View
    private lateinit var selBar: LinearLayout
    private lateinit var prefs: SharedPreferences
    private val toolButtons = LinkedHashMap<Tool, Button>()
    private var ghostBtn: Button? = null

    private var btnSize = 1
    private var barPos = 0
    private var barVertical = false

    private val reqLoad = 1
    private val reqSave = 2
    private val reqPaste = 3
    private val reqSaveTga = 4

    private val colorHistory = mutableListOf<Int>()
    private val histViews = ArrayList<View>()

    // time machine checkpoints (front = newest), max 8
    private val checkpoints = mutableListOf<Pair<String, Bitmap>>()

    private val palette = intArrayOf(
        Color.rgb(0, 0, 0), Color.rgb(255, 255, 255), Color.rgb(127, 127, 127), Color.rgb(195, 195, 195),
        Color.rgb(136, 0, 21), Color.rgb(237, 28, 36), Color.rgb(255, 127, 39), Color.rgb(255, 242, 0),
        Color.rgb(34, 177, 76), Color.rgb(0, 162, 232), Color.rgb(63, 72, 204), Color.rgb(163, 73, 164),
        Color.rgb(185, 122, 87), Color.rgb(255, 174, 201), Color.rgb(255, 201, 14), Color.rgb(153, 217, 234)
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun btnH(): Int = dp(when (btnSize) { 0 -> 36; 2 -> 54; else -> 44 })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getPreferences(Context.MODE_PRIVATE)
        btnSize = prefs.getInt("btn_size", 1)
        barPos = prefs.getInt("bar_pos", 0)
        barVertical = barPos == 2

        pixelView = PixelView(this)
        colorChip = View(this)
        colorChip.setOnClickListener { showShades(pixelView.currentColor) }

        selBar = LinearLayout(this)
        selBar.orientation = LinearLayout.HORIZONTAL
        selBar.visibility = View.GONE
        buildSelBar()

        val root = LinearLayout(this)
        root.setBackgroundColor(Color.rgb(24, 24, 24))
        root.fitsSystemWindows = true

        val toolbarView = buildToolbar()
        if (barVertical) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(pixelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            col.addView(selBar)
            root.orientation = LinearLayout.HORIZONTAL
            root.addView(toolbarView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            root.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        } else {
            root.orientation = LinearLayout.VERTICAL
            if (barPos == 1) root.addView(toolbarView)
            root.addView(pixelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            root.addView(selBar)
            if (barPos == 0) root.addView(toolbarView)
        }
        setContentView(root)

        val s = stash
        if (s != null) {
            stash = null
            pixelView.loadBitmap(s)
        }

        pixelView.onColorPicked = { c ->
            setColor(c)
            selectTool(Tool.PENCIL)
        }
        pixelView.onSelectionChanged = { active ->
            selBar.visibility = if (active) View.VISIBLE else View.GONE
        }
        setColor(Color.BLACK)
        selectTool(Tool.PENCIL)
    }

    // ---------- UI building ----------

    private fun buildToolbar(): View {
        val row = LinearLayout(this)
        row.orientation = if (barVertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL

        val chipLp = LinearLayout.LayoutParams(dp(34), dp(34))
        chipLp.setMargins(dp(4), dp(4), dp(4), dp(4))
        row.addView(colorChip, chipLp)

        addToolButton(row, "\u270f\ufe0f Pencil", Tool.PENCIL, barVertical)
        addMenuButton(row, "\uD83D\uDCE0 Tools", { toolsItems() }, barVertical)
        addToolButton(row, "\u25e7 Select", Tool.SELECT, barVertical)
        addToolButton(row, "\u270b Hand", Tool.HAND, barVertical)
        addButton(row, "\u21b6 Undo", barVertical) { pixelView.undo() }
        addButton(row, "\u21b7 Redo", barVertical) { pixelView.redo() }
        addButton(row, "\u229e Grid", barVertical) { pixelView.showGrid = !pixelView.showGrid }
        addGhostButton(row)
        addMenuButton(row, "\u25a9 Zones", { zonesItems() }, barVertical)
        addButton(row, "\uD83C\uDFA8 Colors", barVertical) { openColors() }
        addMenuButton(
            row, "\uD83D\uDCC1 File", {
                listOf(
                    "\uD83D\uDCBE Save PNG" to { savePng() },
                    "\uD83D\uDDC3 Save TGA" to { saveTga() },
                    "\uD83D\uDCC2 Load image" to { pickImage(reqLoad) },
                    "\uD83D\uDCE5 Paste image" to { pickImage(reqPaste) },
                    "\uD83D\uDCF8 Checkpoint\u2026" to { askCheckpoint() },
                    "\u23f3 Time Machine\u2026" to { askRestore() }
                )
            }, barVertical
        )
        addMenuButton(
            row, "\uD83D\uDDBC Canvas", {
                listOf(
                    "\uD83C\uDD95 New\u2026" to {
                        askSize("New canvas", 32, 32) { w, h -> pixelView.newCanvas(w, h) }
                    },
                    "\u2194\ufe0f Resize\u2026" to {
                        askSize("Resize canvas", pixelView.bitmap.width, pixelView.bitmap.height) { w, h ->
                            pixelView.resizeCanvas(w, h)
                        }
                    },
                    "\u2b1c Clear (transparent)" to { pixelView.clearCanvas() },
                    "\uD83D\uDD8C Fill background" to { pixelView.fillBackground(pixelView.currentColor) }
                )
            }, barVertical
        )
        addMenuButton(row, "\u2699 Settings", { settingsItems() }, barVertical)

        return if (barVertical) {
            val sv = ScrollView(this)
            sv.addView(row)
            sv
        } else {
            val hs = HorizontalScrollView(this)
            hs.addView(row)
            hs
        }
    }

    private fun toolsItems(): List<Pair<String, () -> Unit>> {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items.add(toolEntry(Tool.ERASER, "\uD83E\uDE79", "Eraser"))
        items.add(toolEntry(Tool.FILL, "\uD83E\uDCA3", "Fill"))
        items.add(toolEntry(Tool.PICKER, "\uD83C\uDFA8", "Pick"))
        items.add(toolEntry(Tool.WAND, "\uD83E\uDE84", "Wand (same color)"))
        for (bs in 1..3) {
            val lbl = (if (pixelView.brushSize == bs) "\u2713 " else "") + "\u25a4 Brush: " + bs + "x" + bs
            items.add(lbl to { pixelView.brushSize = bs })
        }
        items.add(((if (pixelView.dither) "\u2713 " else "") + "\u25a7 Dither: " + if (pixelView.dither) "ON" else "off") to { pixelView.dither = !pixelView.dither })
        items.add("\uD83D\uDD01 Swap color\u2026" to {
            pixelView.requestSwap()
            Toast.makeText(this, "Tap a pixel of the color to replace everywhere", Toast.LENGTH_LONG).show()
        })
        return items
    }

    private fun zonesItems(): List<Pair<String, () -> Unit>> {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items.add(((if (!pixelView.zonesOn) "\u2713 " else "") + "Zones: off") to {
            pixelView.setZones(false, pixelView.zoneCell, pixelView.zoneAlpha)
        })
        items.add(((if (pixelView.zonesOn) "\u2713 " else "") + "Zones: ON") to {
            pixelView.setZones(true, pixelView.zoneCell, pixelView.zoneAlpha)
        })
        for (cell in intArrayOf(8, 10, 16, 32)) {
            val lbl = (if (pixelView.zoneCell == cell) "\u2713 " else "") + "Cell: " + cell + "px"
            items.add(lbl to { pixelView.setZones(true, cell, pixelView.zoneAlpha) })
        }
        val alphas = arrayOf("Faint" to 40, "Medium" to 80, "Strong" to 130)
        for (a in alphas) {
            val lbl = (if (pixelView.zoneAlpha == a.second) "\u2713 " else "") + "Opacity: " + a.first
            items.add(lbl to { pixelView.setZones(pixelView.zonesOn, pixelView.zoneCell, a.second) })
        }
        return items
    }

    private fun ghostLabel(): String {
        return if (pixelView.ghostN < 2) "\uD83D\uDC7B Ghost" else "\uD83D\uDC7B " + pixelView.ghostN + "x" + pixelView.ghostN
    }

    private fun addGhostButton(row: LinearLayout) {
        ghostBtn = makeButton(ghostLabel()) {
            val n = when {
                pixelView.ghostN < 2 -> 2
                pixelView.ghostN >= 5 -> 0
                else -> pixelView.ghostN + 1
            }
            pixelView.setGhost(n)
            ghostBtn?.text = ghostLabel()
        }
        val lp = if (barVertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(ghostBtn, lp)
    }

    private fun toolEntry(t: Tool, icon: String, name: String): Pair<String, () -> Unit> {
        val lbl = (if (pixelView.tool == t) "\u2713 " else "") + icon + " " + name
        return lbl to { selectTool(t) }
    }

    private fun settingsItems(): List<Pair<String, () -> Unit>> {
        val sizeNames = arrayOf("Small", "Normal", "Big")
        val posNames = arrayOf("Bottom", "Top", "Left (vertical)")
        val items = mutableListOf<Pair<String, () -> Unit>>()
        for (s in 0..2) {
            val lbl = (if (btnSize == s) "\u2713 " else "") + "Button size: " + sizeNames[s]
            items.add(lbl to { setPref("btn_size", s) })
        }
        for (p in 0..2) {
            val lbl = (if (barPos == p) "\u2713 " else "") + "Toolbar: " + posNames[p]
            items.add(lbl to { setPref("bar_pos", p) })
        }
        return items
    }

    private fun setPref(key: String, v: Int) {
        prefs.edit().putInt(key, v).apply()
        pixelView.stampSelection()
        stash = pixelView.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        recreate()
    }

    private fun buildSelBar() {
        addButton(selBar, "\uD83D\uDCCB Copy") { pixelView.copySelection() }
        addButton(selBar, "\u27f3 Rotate") { pixelView.rotateSelection() }
        addButton(selBar, "\u21cb Flip H") { pixelView.flipSelection(true) }
        addButton(selBar, "\u21c5 Flip V") { pixelView.flipSelection(false) }
        addButton(selBar, "\u2713 Place") { pixelView.stampSelection() }
        addButton(selBar, "\u2715 Cancel") { pixelView.cancelSelection() }
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 13f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(10), 0, dp(10), 0)
        b.setBackgroundColor(Color.rgb(60, 60, 60))
        b.setTextColor(Color.WHITE)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addButton(row: LinearLayout, label: String, vertical: Boolean = false, onClick: () -> Unit) {
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(makeButton(label, onClick), lp)
    }

    private fun addMenuButton(row: LinearLayout, label: String, items: () -> List<Pair<String, () -> Unit>>, vertical: Boolean = false) {
        val b = makeButton(label) {}
        b.setOnClickListener { v ->
            val list = items()
            val pm = PopupMenu(this, v)
            for (i in list.indices) {
                pm.menu.add(0, i, i, list[i].first)
            }
            pm.setOnMenuItemClickListener { mi ->
                list[mi.itemId].second()
                true
            }
            pm.show()
        }
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addToolButton(row: LinearLayout, label: String, t: Tool, vertical: Boolean = false) {
        val b = makeButton(label) { selectTool(t) }
        toolButtons[t] = b
        val lp = if (vertical) {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH())
        } else {
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, btnH())
        }
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun selectTool(t: Tool) {
        pixelView.tool = t
        for ((tool, btn) in toolButtons) {
            if (tool == t) {
                btn.setBackgroundColor(Color.rgb(70, 110, 200))
            } else {
                btn.setBackgroundColor(Color.rgb(60, 60, 60))
            }
        }
    }

    private fun setColor(c: Int) {
        val old = pixelView.currentColor
        if (old != c) {
            colorHistory.add(0, old)
            while (colorHistory.size > 5) {
                colorHistory.removeAt(colorHistory.size - 1)
            }
        }
        pixelView.currentColor = c
        colorChip.setBackgroundColor(c)
        updateHistoryViews()
    }

    private fun updateHistoryViews() {
        for (i in histViews.indices) {
            val hv = histViews[i]
            if (i < colorHistory.size) {
                hv.visibility = View.VISIBLE
                hv.setBackgroundColor(colorHistory[i])
            } else {
                hv.visibility = View.INVISIBLE
            }
        }
    }

    // ---------- colors window ----------

    private fun openColors() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(4), dp(12), dp(4))

        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.gravity = Gravity.CENTER_VERTICAL
        histViews.clear()
        var dlg: AlertDialog? = null
        for (i in 0 until 5) {
            val hv = View(this)
            hv.setBackgroundColor(Color.WHITE)
            hv.setOnClickListener {
                if (i < colorHistory.size) {
                    setColor(colorHistory[i])
                    dlg?.dismiss()
                }
            }
            hv.setOnLongClickListener {
                if (i < colorHistory.size) showShades(colorHistory[i])
                true
            }
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            hrow.addView(hv, lp)
            histViews.add(hv)
        }
        box.addView(hrow)
        updateHistoryViews()

        val swrap = HorizontalScrollView(this)
        val srow = LinearLayout(this)
        srow.orientation = LinearLayout.HORIZONTAL
        srow.gravity = Gravity.CENTER_VERTICAL
        for (c in palette) {
            val sw = View(this)
            sw.setBackgroundColor(c)
            sw.setOnClickListener {
                setColor(c)
                dlg?.dismiss()
            }
            sw.setOnLongClickListener { showShades(c); true }
            val lp = LinearLayout.LayoutParams(dp(38), dp(38))
            lp.setMargins(dp(3), dp(6), dp(3), dp(6))
            srow.addView(sw, lp)
        }
        swrap.addView(srow)
        box.addView(swrap)

        val hexBtn = makeButton("#  Hex") {
            dlg?.dismiss()
            askHex()
        }
        box.addView(hexBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH()))

        val gradBtn = makeButton("\uD83C\uDF17  Gradient\u2026") {
            dlg?.dismiss()
            openGradient()
        }
        box.addView(gradBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnH()))

        dlg = AlertDialog.Builder(this)
            .setTitle("Colors")
            .setView(box)
            .setNegativeButton("Close", null)
            .create()
        dlg?.show()
    }

    // ---------- shades + gradient ----------

    private fun shadesOf(c: Int, steps: Int = 5): IntArray {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        val out = IntArray(steps * 2 + 1)
        for (i in -steps..steps) {
            val v = (hsv[2] * (1f + 0.13f * i)).coerceIn(0.02f, 1f)
            out[i + steps] = Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], v))
        }
        return out
    }

    private fun rampColors(c1: Int, c2: Int, n: Int): IntArray {
        val steps = n.coerceIn(2, 16)
        val out = IntArray(steps)
        for (i in 0 until steps) {
            val t = i.toFloat() / (steps - 1)
            val r = (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * t + 0.5f).toInt().coerceIn(0, 255)
            val g = (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * t + 0.5f).toInt().coerceIn(0, 255)
            val b = (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * t + 0.5f).toInt().coerceIn(0, 255)
            out[i] = Color.rgb(r, g, b)
        }
        return out
    }

    private fun hexOf(c: Int): String = "%06X".format(c and 0xFFFFFF)

    private fun showStrip(title: String, cols: IntArray) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val scroll = HorizontalScrollView(this)
        scroll.addView(row)
        val dlg = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setNegativeButton("Cancel", null)
            .create()
        for (s in cols) {
            val sw = View(this)
            sw.setBackgroundColor(s)
            sw.setOnClickListener {
                setColor(s)
                dlg.dismiss()
            }
            val lp = LinearLayout.LayoutParams(dp(34), dp(44))
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            row.addView(sw, lp)
        }
        dlg.show()
    }

    private fun showShades(c: Int) {
        showStrip("Shades", shadesOf(c))
    }

    private fun openGradient() {
        val fromBox = EditText(this)
        fromBox.setText(hexOf(pixelView.currentColor))
        val toBox = EditText(this)
        toBox.hint = "RRGGBB"
        val stepsBox = numberBox(5)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(label("From (hex)"))
        box.addView(fromBox)
        box.addView(label("To (hex)"))
        box.addView(toBox)
        box.addView(label("Steps (2-16)"))
        box.addView(stepsBox)
        AlertDialog.Builder(this)
            .setTitle("Gradient ramp")
            .setView(box)
            .setPositiveButton("Generate") { _, _ ->
                try {
                    val c1 = Color.parseColor("#" + fromBox.text.toString().trim().removePrefix("#"))
                    val c2 = Color.parseColor("#" + toBox.text.toString().trim().removePrefix("#"))
                    val n = stepsBox.text.toString().toIntOrNull() ?: 5
                    showStrip("Ramp", rampColors(c1, c2, n))
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid colors", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- time machine ----------

    private fun askCheckpoint() {
        val box = EditText(this)
        box.setText("Checkpoint " + (checkpoints.size + 1))
        AlertDialog.Builder(this)
            .setTitle("Save checkpoint")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                pixelView.stampSelection()
                val name = box.text.toString().ifBlank { "Checkpoint" }
                checkpoints.add(0, name to pixelView.bitmap.copy(Bitmap.Config.ARGB_8888, false))
                while (checkpoints.size > 8) {
                    checkpoints.removeAt(checkpoints.size - 1)
                }
                Toast.makeText(this, "Checkpoint saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askRestore() {
        if (checkpoints.isEmpty()) {
            Toast.makeText(this, "No checkpoints yet", Toast.LENGTH_SHORT).show()
            return
        }
        val names = checkpoints.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Back in Time")
            .setItems(names) { _, which ->
                val name = checkpoints[which].first
                val bmp = checkpoints[which].second
                AlertDialog.Builder(this)
                    .setTitle("Restore checkpoint?")
                    .setMessage("Jump back to "" + name + ""? Your current state stays available in Undo.")
                    .setPositiveButton("Restore") { _, _ -> pixelView.restoreCheckpoint(bmp) }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- dialogs ----------

    private fun numberBox(v: Int): EditText {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(v.toString())
        return e
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        return tv
    }

    private fun askSize(title: String, defW: Int, defH: Int, onOk: (Int, Int) -> Unit) {
        val wBox = numberBox(defW)
        val hBox = numberBox(defH)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(label("Width (1-512)"))
        box.addView(wBox)
        box.addView(label("Height (1-512)"))
        box.addView(hBox)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val w = wBox.text.toString().toIntOrNull() ?: 0
                val h = hBox.text.toString().toIntOrNull() ?: 0
                if (w in 1..512 && h in 1..512) {
                    onOk(w, h)
                } else {
                    Toast.makeText(this, "Size must be 1 to 512", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askHex() {
        val box = EditText(this)
        box.hint = "RRGGBB"
        AlertDialog.Builder(this)
            .setTitle("Hex color")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                try {
                    val s = box.text.toString().trim().removePrefix("#")
                    setColor(Color.parseColor("#" + s) or Color.BLACK)
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid color", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- files ----------

    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.type = "*/*"
        startActivityForResult(Intent.createChooser(i, "Pick image (PNG or TGA)"), req)
    }

    private fun savePng() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_TITLE, "pixel.png")
        startActivityForResult(i, reqSave)
    }

    private fun saveTga() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/octet-stream"
        i.putExtra(Intent.EXTRA_TITLE, "pixel.tga")
        startActivityForResult(i, reqSaveTga)
    }

    private fun displayName(uri: Uri): String? {
        var name: String? = null
        try {
            val c = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (c != null && c.moveToFirst()) {
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    name = c.getString(idx)
                }
            }
            c?.close()
        } catch (e: Exception) {
            name = null
        }
        return name
    }

    private fun decode(uri: Uri): Bitmap? {
        val name = displayName(uri)
        var bmp: Bitmap? = null
        try {
            val stream = contentResolver.openInputStream(uri)
            if (stream != null) {
                if (name != null && name.endsWith(".tga", ignoreCase = true)) {
                    bmp = TgaCodec.decode(stream)
                } else {
                    val o = BitmapFactory.Options()
                    o.inScaled = false
                    o.inPreferredConfig = Bitmap.Config.ARGB_8888
                    bmp = BitmapFactory.decodeStream(stream, null, o)
                }
                stream.close()
            }
        } catch (e: Exception) {
            bmp = null
        }
        if (bmp == null) {
            Toast.makeText(this, "Could not open image", Toast.LENGTH_SHORT).show()
            return null
        }
        if (bmp.width > 1024 || bmp.height > 1024) {
            Toast.makeText(this, "Image too big (max 1024x1024)", Toast.LENGTH_SHORT).show()
            return null
        }
        return bmp
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        if (requestCode == reqLoad) {
            val b = decode(uri)
            if (b != null) pixelView.loadBitmap(b)
        } else if (requestCode == reqPaste) {
            val b = decode(uri)
            if (b != null) pixelView.beginPaste(b)
        } else if (requestCode == reqSave) {
            try {
                val out = contentResolver.openOutputStream(uri)
                if (out != null) {
                    pixelView.bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.close()
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
            }
        } else if (requestCode == reqSaveTga) {
            try {
                val out = contentResolver.openOutputStream(uri)
                if (out != null) {
                    if (TgaCodec.encode(pixelView.bitmap, out)) {
                        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
                    }
                    out.close()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
