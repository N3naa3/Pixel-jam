package com.pixelpack.editor

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var pixelView: PixelView
    private lateinit var colorChip: View
    private lateinit var selBar: LinearLayout
    private val toolButtons = LinkedHashMap<Tool, Button>()

    private val reqLoad = 1
    private val reqSave = 2
    private val reqPaste = 3

    private val palette = intArrayOf(
        Color.rgb(0, 0, 0), Color.rgb(255, 255, 255), Color.rgb(127, 127, 127), Color.rgb(195, 195, 195),
        Color.rgb(136, 0, 21), Color.rgb(237, 28, 36), Color.rgb(255, 127, 39), Color.rgb(255, 242, 0),
        Color.rgb(34, 177, 76), Color.rgb(0, 162, 232), Color.rgb(63, 72, 204), Color.rgb(163, 73, 164),
        Color.rgb(185, 122, 87), Color.rgb(255, 174, 201), Color.rgb(255, 201, 14), Color.rgb(153, 217, 234)
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pixelView = PixelView(this)
        colorChip = View(this)

        selBar = LinearLayout(this)
        selBar.orientation = LinearLayout.HORIZONTAL
        selBar.visibility = View.GONE
        buildSelBar()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.rgb(24, 24, 24))
        root.fitsSystemWindows = true

        root.addView(pixelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(selBar)
        root.addView(buildToolbar())
        root.addView(buildPalette())
        setContentView(root)

        pixelView.onColorPicked = { c -> setColor(c) }
        pixelView.onSelectionChanged = { active ->
            selBar.visibility = if (active) View.VISIBLE else View.GONE
        }
        setColor(Color.BLACK)
        selectTool(Tool.PENCIL)
    }

    // ---------- UI building ----------

    private fun buildToolbar(): View {
        val scroll = HorizontalScrollView(this)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        scroll.addView(row)

        addToolButton(row, "\u270f\ufe0f Pencil", Tool.PENCIL)
        addToolButton(row, "\uD83E\uDE79 Eraser", Tool.ERASER)
        addToolButton(row, "\uD83E\uDCA3 Fill", Tool.FILL)
        addToolButton(row, "\uD83C\uDFA8 Pick", Tool.PICKER)
        addToolButton(row, "\u25e7 Select", Tool.SELECT)
        addButton(row, "\u21b6 Undo") { pixelView.undo() }
        addButton(row, "\u21b7 Redo") { pixelView.redo() }
        addButton(row, "\u229e Grid") { pixelView.showGrid = !pixelView.showGrid }
        addMenuButton(
            row, "\uD83D\uDCC1 File", listOf(
                "\uD83D\uDCBE Save PNG" to { saveImage() },
                "\uD83D\uDCC2 Load PNG" to { pickImage(reqLoad) },
                "\uD83D\uDCE5 Paste PNG" to { pickImage(reqPaste) }
            )
        )
        addMenuButton(
            row, "\uD83D\uDDBC Canvas", listOf(
                "\uD83C\uDD95 New\u2026" to {
                    askSize("New canvas", 32, 32) { w, h -> pixelView.newCanvas(w, h) }
                },
                "\u2194\ufe0f Resize\u2026" to {
                    askSize("Resize canvas", pixelView.bitmap.width, pixelView.bitmap.height) { w, h ->
                        pixelView.resizeCanvas(w, h)
                    }
                },
                "\u2b1c Clear (transparent)" to { pixelView.clearCanvas() },
                "\uD83D\uD58C Fill background" to { pixelView.fillBackground(pixelView.currentColor) }
            )
        )
        return scroll
    }

    private fun buildSelBar() {
        addButton(selBar, "\u27f3 Rotate") { pixelView.rotateSelection() }
        addButton(selBar, "\u21cb Flip H") { pixelView.flipSelection(true) }
        addButton(selBar, "\u21c5 Flip V") { pixelView.flipSelection(false) }
        addButton(selBar, "\u2713 Place") { pixelView.stampSelection() }
        addButton(selBar, "\u2715 Cancel") { pixelView.cancelSelection() }
    }

    private fun buildPalette(): View {
        val scroll = HorizontalScrollView(this)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        scroll.addView(row)

        val chipLp = LinearLayout.LayoutParams(dp(44), dp(44))
        chipLp.setMargins(dp(4), dp(4), dp(10), dp(4))
        row.addView(colorChip, chipLp)

        for (c in palette) {
            val sw = View(this)
            sw.setBackgroundColor(c)
            sw.setOnClickListener { setColor(c) }
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.setMargins(dp(3), dp(4), dp(3), dp(4))
            row.addView(sw, lp)
        }
        addButton(row, "Hex") { askHex() }
        return scroll
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 13f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(10), 0, dp(10), 0)
        b.setBackgroundColor(Color.rgb(60, 60, 60))
        b.setTextColor(Color.WHITE)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addButton(row: LinearLayout, label: String, onClick: () -> Unit) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(makeButton(label, onClick), lp)
    }

    private fun addMenuButton(row: LinearLayout, label: String, items: List<Pair<String, () -> Unit>>) {
        val b = makeButton(label) {}
        b.setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            for (i in items.indices) {
                pm.menu.add(0, i, i, items[i].first)
            }
            pm.setOnMenuItemClickListener { mi ->
                items[mi.itemId].second()
                true
            }
            pm.show()
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun addToolButton(row: LinearLayout, label: String, t: Tool) {
        val b = makeButton(label) { selectTool(t) }
        toolButtons[t] = b
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        row.addView(b, lp)
    }

    private fun selectTool(t: Tool) {
        pixelView.tool = t
        for ((tool, btn) in toolButtons) {
            if (tool == t) {
                btn.setBackgroundColor(Color.rgb(70, 110, 200))
            } else {
                btn.setBackgroundColor(Color.rgb(60, 60, 60))
            }
        }
    }

    private fun setColor(c: Int) {
        pixelView.currentColor = c
        colorChip.setBackgroundColor(c)
    }

    // ---------- dialogs ----------

    private fun numberBox(v: Int): EditText {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(v.toString())
        return e
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        return tv
    }

    private fun askSize(title: String, defW: Int, defH: Int, onOk: (Int, Int) -> Unit) {
        val wBox = numberBox(defW)
        val hBox = numberBox(defH)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(label("Width (1-512)"))
        box.addView(wBox)
        box.addView(label("Height (1-512)"))
        box.addView(hBox)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val w = wBox.text.toString().toIntOrNull() ?: 0
                val h = hBox.text.toString().toIntOrNull() ?: 0
                if (w in 1..512 && h in 1..512) {
                    onOk(w, h)
                } else {
                    Toast.makeText(this, "Size must be 1 to 512", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askHex() {
        val box = EditText(this)
        box.hint = "RRGGBB"
        AlertDialog.Builder(this)
            .setTitle("Hex color")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                try {
                    val s = box.text.toString().trim().removePrefix("#")
                    setColor(Color.parseColor("#" + s) or Color.BLACK)
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid color", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- files ----------

    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.type = "image/*"
        startActivityForResult(Intent.createChooser(i, "Pick image"), req)
    }

    private fun saveImage() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_TITLE, "pixel.png")
        startActivityForResult(i, reqSave)
    }

    private fun decode(uri: Uri): Bitmap? {
        var bmp: Bitmap? = null
        try {
            val stream = contentResolver.openInputStream(uri)
            if (stream != null) {
                val o = BitmapFactory.Options()
                o.inScaled = false
                o.inPreferredConfig = Bitmap.Config.ARGB_8888
                bmp = BitmapFactory.decodeStream(stream, null, o)
                stream.close()
            }
        } catch (e: Exception) {
            bmp = null
        }
        if (bmp == null) {
            Toast.makeText(this, "Could not open image", Toast.LENGTH_SHORT).show()
            return null
        }
        if (bmp.width > 1024 || bmp.height > 1024) {
            Toast.makeText(this, "Image too big (max 1024x1024)", Toast.LENGTH_SHORT).show()
            return null
        }
        return bmp
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        if (requestCode == reqLoad) {
            val b = decode(uri)
            if (b != null) pixelView.loadBitmap(b)
        } else if (requestCode == reqPaste) {
            val b = decode(uri)
            if (b != null) pixelView.beginPaste(b)
        } else if (requestCode == reqSave) {
            try {
                val out = contentResolver.openOutputStream(uri)
                if (out != null) {
                    pixelView.bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.close()
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
