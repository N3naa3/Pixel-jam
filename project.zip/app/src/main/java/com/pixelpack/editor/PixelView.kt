package com.pixelpack.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

enum class Tool { PENCIL, ERASER, FILL, PICKER, SELECT, HAND, WAND }

class PixelView(context: Context) : View(context) {

    var bitmap: Bitmap = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
        private set

    var tool: Tool = Tool.PENCIL
    var currentColor: Int = Color.BLACK
    var onColorPicked: ((Int) -> Unit)? = null
    var onSelectionChanged: ((Boolean) -> Unit)? = null

    var showGrid: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    // brush: 1x1 / 2x2 / 3x3 (pencil + eraser)
    var brushSize = 1

    // checkerboard dither for pencil
    var dither = false

    // ghost blocks preview: 0 = off, 2..5 = repeat count
    var ghostN = 0
        private set

    // glyph zone checkerboard
    var zonesOn = false
        private set
    var zoneCell = 16
        private set
    var zoneAlpha = 80
        private set

    var hasSelection: Boolean = false
        private set

    // floating selection state
    private var selX = 0
    private var selY = 0
    private var selW = 0
    private var selH = 0
    private var selOriginX = 0
    private var selOriginY = 0
    private var selBmp: Bitmap? = null
    private var selCut = false

    // marquee (while dragging out a new selection)
    private var marActive = false
    private var marX0 = 0
    private var marY0 = 0
    private var marX1 = 0
    private var marY1 = 0

    // moving an active selection
    private var moveDrag = false
    private var moveOffX = 0
    private var moveOffY = 0

    // hand tool one-finger pan
    private var handDrag = false
    private var handLastX = 0f
    private var handLastY = 0f

    // color swap: next canvas tap replaces that color everywhere
    private var pendingSwap = false

    private var checker: Bitmap = makeChecker(32, 32)
    private val undoStack = ArrayList<Bitmap>()
    private val redoStack = ArrayList<Bitmap>()

    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var needFit = true

    private val bmpPaint = Paint()
    private val ghostPaint = Paint()
    private val gridPaint = Paint()
    private val zonePaint = Paint()
    private val clearPaint = Paint()
    private val borderBlack = Paint()
    private val borderWhite = Paint()

    private var strokeActive = false
    private var lastPx = 0
    private var lastPy = 0
    private var multi = false
    private var lastFx = Float.NaN
    private var lastFy = Float.NaN

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val newScale = (scale * detector.scaleFactor).coerceIn(0.5f, 80f)
                val real = newScale / scale
                tx = detector.focusX - (detector.focusX - tx) * real
                ty = detector.focusY - (detector.focusY - ty) * real
                scale = newScale
                invalidate()
                return true
            }
        }
    )

    init {
        bmpPaint.isFilterBitmap = false
        bmpPaint.isAntiAlias = false
        ghostPaint.isFilterBitmap = false
        ghostPaint.isAntiAlias = false
        ghostPaint.alpha = 110
        gridPaint.color = Color.argb(90, 0, 0, 0)
        gridPaint.strokeWidth = 1f
        clearPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        borderBlack.color = Color.BLACK
        borderBlack.style = Paint.Style.STROKE
        borderBlack.strokeWidth = 4f
        borderWhite.color = Color.WHITE
        borderWhite.style = Paint.Style.STROKE
        borderWhite.strokeWidth = 2f
        borderWhite.pathEffect = DashPathEffect(floatArrayOf(10f, 6f), 0f)
    }

    // ---------- public API ----------

    fun loadBitmap(b: Bitmap) {
        stampSelection()
        undoStack.clear()
        redoStack.clear()
        applyBitmap(copyOf(b), true)
    }

    fun newCanvas(w: Int, h: Int) {
        loadBitmap(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))
    }

    fun resizeCanvas(w: Int, h: Int) {
        stampSelection()
        pushUndo()
        val nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(nb).drawBitmap(bitmap, 0f, 0f, null)
        applyBitmap(nb, true)
    }

    fun clearCanvas() {
        stampSelection()
        pushUndo()
        bitmap.eraseColor(Color.TRANSPARENT)
        invalidate()
    }

    fun fillBackground(c: Int) {
        stampSelection()
        pushUndo()
        bitmap.eraseColor(c)
        invalidate()
    }

    fun undo() {
        stampSelection()
        if (undoStack.isEmpty()) return
        redoStack.add(copyOf(bitmap))
        applyBitmap(undoStack.removeAt(undoStack.size - 1), false)
    }

    fun redo() {
        stampSelection()
        if (redoStack.isEmpty()) return
        undoStack.add(copyOf(bitmap))
        applyBitmap(redoStack.removeAt(redoStack.size - 1), false)
    }

    // jump back to a Time Machine checkpoint
    fun restoreCheckpoint(b: Bitmap) {
        stampSelection()
        pushUndo()
        applyBitmap(copyOf(b), true)
    }

    fun setGhost(n: Int) {
        ghostN = n.coerceIn(0, 5)
        invalidate()
    }

    fun setZones(on: Boolean, cell: Int, alpha: Int) {
        zonesOn = on
        zoneCell = cell.coerceIn(2, 256)
        zoneAlpha = alpha.coerceIn(10, 160)
        invalidate()
    }

    // floating selection from a loaded file
    fun beginPaste(src: Bitmap) {
        stampSelection()
        pushUndo()
        var b = src
        if (b.width > bitmap.width || b.height > bitmap.height) {
            val s = min(bitmap.width.toFloat() / b.width, bitmap.height.toFloat() / b.height)
            val nw = max(1, (b.width * s).toInt())
            val nh = max(1, (b.height * s).toInt())
            val nb = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888)
            Canvas(nb).drawBitmap(b, null, Rect(0, 0, nw, nh), bmpPaint)
            b = nb
        }
        setSelection(b, (bitmap.width - b.width) / 2, (bitmap.height - b.height) / 2, false)
    }

    // turn a cut selection into a copy: original pixels return underneath
    fun copySelection() {
        if (!hasSelection) return
        if (selCut) {
            val b = selBmp ?: return
            Canvas(bitmap).drawBitmap(b, selOriginX.toFloat(), selOriginY.toFloat(), null)
            selCut = false
            invalidate()
        }
    }

    // wand: select ALL pixels of the tapped color (floating, non-destructive)
    fun selectColorAt(x: Int, y: Int) {
        if (!inside(x, y)) return
        stampSelection()
        val target = bitmap.getPixel(x, y)
        val w = bitmap.width
        val h = bitmap.height
        val px = IntArray(w * h)
        bitmap.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (yy in 0 until h) {
            for (xx in 0 until w) {
                if (px[yy * w + xx] == target) {
                    if (xx < minX) minX = xx
                    if (xx > maxX) maxX = xx
                    if (yy < minY) minY = yy
                    if (yy > maxY) maxY = yy
                }
            }
        }
        if (maxX < 0) return
        val bw = maxX - minX + 1
        val bh = maxY - minY + 1
        pushUndo()
        val region = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        region.eraseColor(Color.TRANSPARENT)
        for (yy in minY..maxY) {
            for (xx in minX..maxX) {
                if (px[yy * w + xx] == target) {
                    region.setPixel(xx - minX, yy - minY, target)
                }
            }
        }
        setSelection(region, minX, minY, false)
    }

    // color swap: next canvas tap = replace that color everywhere
    fun requestSwap() {
        stampSelection()
        pendingSwap = true
    }

    fun rotateSelection() {
        val b = selBmp ?: return
        val nb = Bitmap.createBitmap(b.height, b.width, Bitmap.Config.ARGB_8888)
        val m = Matrix()
        m.setRotate(90f)
        m.postTranslate(b.height.toFloat(), 0f)
        Canvas(nb).drawBitmap(b, m, null)
        selBmp = nb
        selW = nb.width
        selH = nb.height
        clampSelection()
        invalidate()
    }

    fun flipSelection(horizontal: Boolean) {
        val b = selBmp ?: return
        val nb = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val m = Matrix()
        if (horizontal) {
            m.setScale(-1f, 1f)
            m.postTranslate(b.width.toFloat(), 0f)
        } else {
            m.setScale(1f, -1f)
            m.postTranslate(0f, b.height.toFloat())
        }
        Canvas(nb).drawBitmap(b, m, null)
        selBmp = nb
        invalidate()
    }

    fun stampSelection() {
        if (!hasSelection) return
        val b = selBmp ?: return
        Canvas(bitmap).drawBitmap(b, selX.toFloat(), selY.toFloat(), null)
        clearSel()
        invalidate()
    }

    fun cancelSelection() {
        if (!hasSelection) return
        if (selCut) {
            val b = selBmp ?: return
            Canvas(bitmap).drawBitmap(b, selOriginX.toFloat(), selOriginY.toFloat(), null)
        }
        clearSel()
        invalidate()
    }

    // ---------- internals ----------

    private fun setSelection(b: Bitmap, x: Int, y: Int, cut: Boolean) {
        selBmp = b
        selX = x
        selY = y
        selW = b.width
        selH = b.height
        selOriginX = x
        selOriginY = y
        selCut = cut
        hasSelection = true
        onSelectionChanged?.invoke(true)
        invalidate()
    }

    private fun clearSel() {
        hasSelection = false
        selBmp = null
        onSelectionChanged?.invoke(false)
    }

    private fun clampSelection() {
        selX = selX.coerceIn(-selW + 1, bitmap.width - 1)
        selY = selY.coerceIn(-selH + 1, bitmap.height - 1)
    }

    private fun commitMarquee() {
        val l = min(marX0, marX1)
        val t = min(marY0, marY1)
        val w = max(marX0, marX1) - l + 1
        val h = max(marY0, marY1) - t + 1
        if (w <= 0 || h <= 0) return
        pushUndo()
        val region = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(region).drawBitmap(bitmap, Rect(l, t, l + w, t + h), Rect(0, 0, w, h), bmpPaint)
        Canvas(bitmap).drawRect(Rect(l, t, l + w, t + h), clearPaint)
        setSelection(region, l, t, true)
    }

    private fun swapColorAt(x: Int, y: Int) {
        if (!inside(x, y)) return
        val target = bitmap.getPixel(x, y)
        val repl = currentColor
        if (target == repl) return
        pushUndo()
        val w = bitmap.width
        val h = bitmap.height
        val px = IntArray(w * h)
        bitmap.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            if (px[i] == target) px[i] = repl
        }
        bitmap.setPixels(px, 0, w, 0, 0, w, h)
        invalidate()
    }

    private fun makeChecker(w: Int, h: Int): Bitmap {
        val px = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                px[y * w + x] = if ((x + y) % 2 == 0) Color.rgb(208, 208, 208) else Color.WHITE
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun copyOf(b: Bitmap): Bitmap {
        val c = b.copy(Bitmap.Config.ARGB_8888, true)
        if (c == null) {
            return Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        }
        return c
    }

    private fun applyBitmap(b: Bitmap, refit: Boolean) {
        val sizeChanged = b.width != checker.width || b.height != checker.height
        bitmap = b
        if (sizeChanged) {
            checker = makeChecker(b.width, b.height)
        }
        if (refit || sizeChanged) {
            needFit = true
        }
        fitIfNeeded()
        invalidate()
    }

    private fun pushUndo() {
        undoStack.add(copyOf(bitmap))
        if (undoStack.size > 40) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
    }

    private fun fitIfNeeded() {
        if (!needFit || width == 0 || height == 0) return
        var s = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        if (s >= 1f) {
            s = floor(s)
        }
        scale = s
        tx = (width - bitmap.width * s) / 2f
        ty = (height - bitmap.height * s) / 2f
        needFit = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (oldw == 0 || oldh == 0) {
            needFit = true
            fitIfNeeded()
            return
        }
        val cx = (oldw / 2f - tx) / scale
        val cy = (oldh / 2f - ty) / scale
        tx = w / 2f - cx * scale
        ty = h / 2f - cy * scale
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.rgb(32, 32, 32))
        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(scale, scale)
        canvas.drawBitmap(checker, 0f, 0f, bmpPaint)
        canvas.drawBitmap(bitmap, 0f, 0f, bmpPaint)

        // ghost blocks preview: repeat the canvas side by side
        if (ghostN > 1) {
            val w = bitmap.width.toFloat()
            val h = bitmap.height.toFloat()
            for (gy in 0 until ghostN) {
                for (gx in 0 until ghostN) {
                    if (gx == 0 && gy == 0) continue
                    canvas.drawBitmap(checker, gx * w, gy * h, bmpPaint)
                    canvas.drawBitmap(bitmap, gx * w, gy * h, bmpPaint)
                }
            }
        }

        // glyph zone checkerboard (pure visual overlay)
        if (zonesOn && zoneCell >= 2) {
            zonePaint.color = Color.argb(zoneAlpha, 0, 0, 0)
            val w = bitmap.width
            val h = bitmap.height
            var cy = 0
            var row = 0
            while (cy < h) {
                var cx = 0
                var col = 0
                while (cx < w) {
                    if ((row + col) % 2 == 1) {
                        canvas.drawRect(
                            cx.toFloat(), cy.toFloat(),
                            min(cx + zoneCell, w).toFloat(), min(cy + zoneCell, h).toFloat(),
                            zonePaint
                        )
                    }
                    cx += zoneCell
                    col++
                }
                cy += zoneCell
                row++
            }
        }
        canvas.restore()

        if (showGrid && scale >= 8f) {
            val w = bitmap.width
            val h = bitmap.height
            val right = tx + w * scale
            val bottom = ty + h * scale
            val vw = width.toFloat()
            val vh = height.toFloat()
            for (x in 0..w) {
                val sx = tx + x * scale
                if (sx < 0f || sx > vw) continue
                canvas.drawLine(sx, ty, sx, bottom, gridPaint)
            }
            for (y in 0..h) {
                val sy = ty + y * scale
                if (sy < 0f || sy > vh) continue
                canvas.drawLine(tx, sy, right, sy, gridPaint)
            }
        }

        if (marActive) {
            val rf = RectF(
                tx + min(marX0, marX1) * scale,
                ty + min(marY0, marY1) * scale,
                tx + (max(marX0, marX1) + 1) * scale,
                ty + (max(marY0, marY1) + 1) * scale
            )
            canvas.drawRect(rf, borderBlack)
            canvas.drawRect(rf, borderWhite)
        }

        val sb = selBmp
        if (hasSelection && sb != null) {
            val l = tx + selX * scale
            val t = ty + selY * scale
            val rf = RectF(l, t, l + selW * scale, t + selH * scale)
            // ghost: whole selection faded
            canvas.drawBitmap(sb, null, rf, ghostPaint)
            // solid: only the part inside the canvas
            canvas.save()
            canvas.clipRect(tx, ty, tx + bitmap.width * scale, ty + bitmap.height * scale)
            canvas.drawBitmap(sb, null, rf, bmpPaint)
            canvas.restore()
            canvas.drawRect(rf, borderBlack)
            canvas.drawRect(rf, borderWhite)
        }
    }

    // ---------- touch ----------

    private fun toPx(sx: Float): Int = floor((sx - tx) / scale).toInt()
    private fun toPy(sy: Float): Int = floor((sy - ty) / scale).toInt()

    private fun inside(x: Int, y: Int): Boolean {
        return x >= 0 && y >= 0 && x < bitmap.width && y < bitmap.height
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false
                lastFx = Float.NaN
                if (pendingSwap) {
                    pendingSwap = false
                    swapColorAt(toPx(ev.x), toPy(ev.y))
                } else {
                    val px = toPx(ev.x)
                    val py = toPy(ev.y)
                    if (hasSelection) {
                        if (tool == Tool.SELECT && px >= selX && px < selX + selW && py >= selY && py < selY + selH) {
                            moveDrag = true
                            moveOffX = px - selX
                            moveOffY = py - selY
                        } else {
                            stampSelection()
                        }
                    }
                    if (!moveDrag) {
                        if (tool == Tool.HAND) {
                            handDrag = true
                            handLastX = ev.x
                            handLastY = ev.y
                        } else if (tool == Tool.SELECT) {
                            if (inside(px, py)) {
                                marActive = true
                                marX0 = px
                                marY0 = py
                                marX1 = px
                                marY1 = py
                                invalidate()
                            }
                        } else {
                            startStroke(px, py)
                        }
                    }
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (strokeActive) {
                    cancelStroke()
                }
                moveDrag = false
                handDrag = false
                marActive = false
                multi = true
                lastFx = Float.NaN
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (ev.pointerCount >= 2) {
                    var fx = 0f
                    var fy = 0f
                    for (i in 0 until ev.pointerCount) {
                        fx += ev.getX(i)
                        fy += ev.getY(i)
                    }
                    fx /= ev.pointerCount
                    fy /= ev.pointerCount
                    if (!lastFx.isNaN()) {
                        tx += fx - lastFx
                        ty += fy - lastFy
                        invalidate()
                    }
                    lastFx = fx
                    lastFy = fy
                } else if (handDrag) {
                    tx += ev.x - handLastX
                    ty += ev.y - handLastY
                    handLastX = ev.x
                    handLastY = ev.y
                    invalidate()
                } else if (moveDrag) {
                    val oldL = (tx + selX * scale).toInt()
                    val oldT = (ty + selY * scale).toInt()
                    val oldR = (tx + (selX + selW) * scale).toInt() + 1
                    val oldB = (ty + (selY + selH) * scale).toInt() + 1
                    selX = (toPx(ev.x) - moveOffX).coerceIn(-selW + 1, bitmap.width - 1)
                    selY = (toPy(ev.y) - moveOffY).coerceIn(-selH + 1, bitmap.height - 1)
                    val newL = (tx + selX * scale).toInt()
                    val newT = (ty + selY * scale).toInt()
                    val newR = (tx + (selX + selW) * scale).toInt() + 1
                    val newB = (ty + (selY + selH) * scale).toInt() + 1
                    invalidate(
                        min(oldL, newL) - 8, min(oldT, newT) - 8,
                        max(oldR, newR) + 8, max(oldB, newB) + 8
                    )
                } else if (marActive) {
                    marX1 = toPx(ev.x).coerceIn(0, bitmap.width - 1)
                    marY1 = toPy(ev.y).coerceIn(0, bitmap.height - 1)
                    invalidate()
                } else if (!multi && strokeActive) {
                    continueStroke(toPx(ev.x), toPy(ev.y))
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                lastFx = Float.NaN
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (marActive && ev.actionMasked == MotionEvent.ACTION_UP) {
                    commitMarquee()
                }
                marActive = false
                moveDrag = false
                handDrag = false
                strokeActive = false
                multi = false
                lastFx = Float.NaN
            }
        }
        return true
    }

    private fun startStroke(x: Int, y: Int) {
        if (!inside(x, y)) return
        when (tool) {
            Tool.PENCIL, Tool.ERASER -> {
                pushUndo()
                strokeActive = true
                lastPx = x
                lastPy = y
                plot(x, y)
                invalidate()
            }
            Tool.FILL -> {
                pushUndo()
                floodFill(x, y, currentColor)
                invalidate()
            }
            Tool.PICKER -> {
                val c = bitmap.getPixel(x, y)
                if (Color.alpha(c) > 0) {
                    currentColor = c
                    onColorPicked?.invoke(c)
                }
            }
            Tool.WAND -> {
                selectColorAt(x, y)
            }
            Tool.SELECT -> {
            }
            Tool.HAND -> {
            }
        }
    }

    private fun continueStroke(x: Int, y: Int) {
        if (x == lastPx && y == lastPy) return
        line(lastPx, lastPy, x, y)
        lastPx = x
        lastPy = y
        invalidate()
    }

    private fun cancelStroke() {
        strokeActive = false
        if (undoStack.isNotEmpty()) {
            applyBitmap(undoStack.removeAt(undoStack.size - 1), false)
        }
    }

    private fun plot(x: Int, y: Int) {
        if (!inside(x, y)) return
        if (tool == Tool.PENCIL && dither && ((x + y) and 1) == 1) return
        val c = if (tool == Tool.ERASER) Color.TRANSPARENT else currentColor
        val n = if (tool == Tool.PENCIL || tool == Tool.ERASER) brushSize else 1
        for (dy in 0 until n) {
            for (dx in 0 until n) {
                val xx = x + dx
                val yy = y + dy
                if (inside(xx, yy)) {
                    bitmap.setPixel(xx, yy, c)
                }
            }
        }
    }

    private fun line(x0: Int, y0: Int, x1: Int, y1: Int) {
        var x = x0
        var y = y0
        val dx = abs(x1 - x0)
        val dy = -abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx + dy
        while (true) {
            plot(x, y)
            if (x == x1 && y == y1) break
            val e2 = 2 * err
            if (e2 >= dy) {
                err += dy
                x += sx
            }
            if (e2 <= dx) {
                err += dx
                y += sy
            }
        }
    }

    private fun floodFill(sx: Int, sy: Int, fill: Int) {
        val w = bitmap.width
        val h = bitmap.height
        val px = IntArray(w * h)
        bitmap.getPixels(px, 0, w, 0, 0, w, h)
        val target = px[sy * w + sx]
        if (target == fill) return
        val stack = IntArray(w * h * 4 + 8)
        var sp = 0
        stack[sp] = sy * w + sx
        sp++
        while (sp > 0) {
            sp--
            val p = stack[sp]
            if (px[p] != target) continue
            px[p] = fill
            val x = p % w
            val y = p / w
            if (x > 0 && px[p - 1] == target) {
                stack[sp] = p - 1
                sp++
            }
            if (x < w - 1 && px[p + 1] == target) {
                stack[sp] = p + 1
                sp++
            }
            if (y > 0 && px[p - w] == target) {
                stack[sp] = p - w
                sp++
            }
            if (y < h - 1 && px[p + w] == target) {
                stack[sp] = p + w
                sp++
            }
        }
        bitmap.setPixels(px, 0, w, 0, 0, w, h)
    }
}
