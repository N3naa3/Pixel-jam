package com.pixelpack.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min

enum class Tool { PENCIL, ERASER, FILL, PICKER }

class PixelView(context: Context) : View(context) {

    var bitmap: Bitmap = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
        private set

    var tool: Tool = Tool.PENCIL
    var currentColor: Int = Color.BLACK
    var onColorPicked: ((Int) -> Unit)? = null

    var showGrid: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    private var checker: Bitmap = makeChecker(32, 32)
    private val undoStack = ArrayList<Bitmap>()
    private val redoStack = ArrayList<Bitmap>()

    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var needFit = true

    private val bmpPaint = Paint()
    private val gridPaint = Paint()

    private var strokeActive = false
    private var lastPx = 0
    private var lastPy = 0
    private var multi = false
    private var lastFx = Float.NaN
    private var lastFy = Float.NaN

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val newScale = (scale * detector.scaleFactor).coerceIn(0.5f, 80f)
                val real = newScale / scale
                tx = detector.focusX - (detector.focusX - tx) * real
                ty = detector.focusY - (detector.focusY - ty) * real
                scale = newScale
                invalidate()
                return true
            }
        }
    )

    init {
        bmpPaint.isFilterBitmap = false
        bmpPaint.isAntiAlias = false
        gridPaint.color = Color.argb(90, 0, 0, 0)
        gridPaint.strokeWidth = 1f
    }

    // ---------- public API ----------

    fun loadBitmap(b: Bitmap) {
        undoStack.clear()
        redoStack.clear()
        applyBitmap(copyOf(b), true)
    }

    fun newCanvas(w: Int, h: Int) {
        loadBitmap(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))
    }

    fun resizeCanvas(w: Int, h: Int) {
        pushUndo()
        val nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(nb).drawBitmap(bitmap, 0f, 0f, null)
        applyBitmap(nb, true)
    }

    fun pasteBitmap(src: Bitmap) {
        pushUndo()
        Canvas(bitmap).drawBitmap(src, 0f, 0f, null)
        invalidate()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(copyOf(bitmap))
        applyBitmap(undoStack.removeAt(undoStack.size - 1), false)
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(copyOf(bitmap))
        applyBitmap(redoStack.removeAt(redoStack.size - 1), false)
    }

    // ---------- internals ----------

    private fun makeChecker(w: Int, h: Int): Bitmap {
        val px = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                px[y * w + x] = if ((x + y) % 2 == 0) Color.rgb(208, 208, 208) else Color.WHITE
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun copyOf(b: Bitmap): Bitmap {
        val c = b.copy(Bitmap.Config.ARGB_8888, true)
        if (c == null) {
            return Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        }
        return c
    }

    private fun applyBitmap(b: Bitmap, refit: Boolean) {
        val sizeChanged = b.width != checker.width || b.height != checker.height
        bitmap = b
        if (sizeChanged) {
            checker = makeChecker(b.width, b.height)
        }
        if (refit || sizeChanged) {
            needFit = true
        }
        fitIfNeeded()
        invalidate()
    }

    private fun pushUndo() {
        undoStack.add(copyOf(bitmap))
        if (undoStack.size > 40) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
    }

    private fun fitIfNeeded() {
        if (!needFit || width == 0 || height == 0) return
        var s = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        if (s >= 1f) {
            s = floor(s)
        }
        scale = s
        tx = (width - bitmap.width * s) / 2f
        ty = (height - bitmap.height * s) / 2f
        needFit = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        needFit = true
        fitIfNeeded()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.rgb(32, 32, 32))
        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(scale, scale)
        canvas.drawBitmap(checker, 0f, 0f, bmpPaint)
        canvas.drawBitmap(bitmap, 0f, 0f, bmpPaint)
        canvas.restore()

        if (showGrid && scale >= 8f) {
            val w = bitmap.width
            val h = bitmap.height
            val right = tx + w * scale
            val bottom = ty + h * scale
            val vw = width.toFloat()
            val vh = height.toFloat()
            for (x in 0..w) {
                val sx = tx + x * scale
                if (sx < 0f || sx > vw) continue
                canvas.drawLine(sx, ty, sx, bottom, gridPaint)
            }
            for (y in 0..h) {
                val sy = ty + y * scale
                if (sy < 0f || sy > vh) continue
                canvas.drawLine(tx, sy, right, sy, gridPaint)
            }
        }
    }

    // ---------- touch ----------

    private fun toPx(sx: Float): Int = floor((sx - tx) / scale).toInt()
    private fun toPy(sy: Float): Int = floor((sy - ty) / scale).toInt()

    private fun inside(x: Int, y: Int): Boolean {
        return x >= 0 && y >= 0 && x < bitmap.width && y < bitmap.height
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false
                lastFx = Float.NaN
                startStroke(toPx(ev.x), toPy(ev.y))
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (strokeActive) {
                    cancelStroke()
                }
                multi = true
                lastFx = Float.NaN
            }
            MotionEvent.ACTION_MOVE -> {
                if (ev.pointerCount >= 2) {
                    var fx = 0f
                    var fy = 0f
                    for (i in 0 until ev.pointerCount) {
                        fx += ev.getX(i)
                        fy += ev.getY(i)
                    }
                    fx /= ev.pointerCount
                    fy /= ev.pointerCount
                    if (!lastFx.isNaN()) {
                        tx += fx - lastFx
                        ty += fy - lastFy
                        invalidate()
                    }
                    lastFx = fx
                    lastFy = fy
                } else if (!multi && strokeActive) {
                    continueStroke(toPx(ev.x), toPy(ev.y))
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                lastFx = Float.NaN
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                strokeActive = false
                multi = false
                lastFx = Float.NaN
            }
        }
        return true
    }

    private fun startStroke(x: Int, y: Int) {
        if (!inside(x, y)) return
        when (tool) {
            Tool.PENCIL, Tool.ERASER -> {
                pushUndo()
                strokeActive = true
                lastPx = x
                lastPy = y
                plot(x, y)
                invalidate()
            }
            Tool.FILL -> {
                pushUndo()
                floodFill(x, y, currentColor)
                invalidate()
            }
            Tool.PICKER -> {
                val c = bitmap.getPixel(x, y)
                if (Color.alpha(c) > 0) {
                    currentColor = c
                    onColorPicked?.invoke(c)
                }
            }
        }
    }

    private fun continueStroke(x: Int, y: Int) {
        if (x == lastPx && y == lastPy) return
        line(lastPx, lastPy, x, y)
        lastPx = x
        lastPy = y
        invalidate()
    }

    private fun cancelStroke() {
        strokeActive = false
        if (undoStack.isNotEmpty()) {
            applyBitmap(undoStack.removeAt(undoStack.size - 1), false)
        }
    }

    private fun plot(x: Int, y: Int) {
        if (!inside(x, y)) return
        val c = if (tool == Tool.ERASER) Color.TRANSPARENT else currentColor
        bitmap.setPixel(x, y, c)
    }

    private fun line(x0: Int, y0: Int, x1: Int, y1: Int) {
        var x = x0
        var y = y0
        val dx = abs(x1 - x0)
        val dy = -abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx + dy
        while (true) {
            plot(x, y)
            if (x == x1 && y == y1) break
            val e2 = 2 * err
            if (e2 >= dy) {
                err += dy
                x += sx
            }
            if (e2 <= dx) {
                err += dx
                y += sy
            }
        }
    }

    private fun floodFill(sx: Int, sy: Int, fill: Int) {
        val w = bitmap.width
        val h = bitmap.height
        val px = IntArray(w * h)
        bitmap.getPixels(px, 0, w, 0, 0, w, h)
        val target = px[sy * w + sx]
        if (target == fill) return
        val stack = IntArray(w * h * 4 + 8)
        var sp = 0
        stack[sp] = sy * w + sx
        sp++
        while (sp > 0) {
            sp--
            val p = stack[sp]
            if (px[p] != target) continue
            px[p] = fill
            val x = p % w
            val y = p / w
            if (x > 0 && px[p - 1] == target) {
                stack[sp] = p - 1
                sp++
            }
            if (x < w - 1 && px[p + 1] == target) {
                stack[sp] = p + 1
                sp++
            }
            if (y > 0 && px[p - w] == target) {
                stack[sp] = p - w
                sp++
            }
            if (y < h - 1 && px[p + w] == target) {
                stack[sp] = p + w
                sp++
            }
        }
        bitmap.setPixels(px, 0, w, 0, 0, w, h)
    }
}
