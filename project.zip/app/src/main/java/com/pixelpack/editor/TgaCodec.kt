package com.pixelpack.editor

import android.graphics.Bitmap
import android.graphics.Color
import java.io.InputStream
import java.io.OutputStream

object TgaCodec {

    fun decode(input: InputStream): Bitmap? {
        return try {
            val h = ByteArray(18)
            if (!readFully(input, h)) return null
            val idLen = h[0].toInt() and 0xFF
            val type = h[2].toInt() and 0xFF
            val w = (h[12].toInt() and 0xFF) or ((h[13].toInt() and 0xFF) shl 8)
            val hgt = (h[14].toInt() and 0xFF) or ((h[15].toInt() and 0xFF) shl 8)
            val depth = h[16].toInt() and 0xFF
            val topOrigin = (h[17].toInt() and 0x20) != 0
            if (w <= 0 || hgt <= 0 || w > 4096 || hgt > 4096) return null
            if (type != 2 && type != 10) return null
            if (depth != 24 && depth != 32) return null
            if (idLen > 0) {
                val skip = ByteArray(idLen)
                if (!readFully(input, skip)) return null
            }
            val bpp = depth / 8
            val px = IntArray(w * hgt)
            val buf = ByteArray(bpp)
            val total = w * hgt
            var index = 0
            if (type == 2) {
                while (index < total) {
                    if (!readFully(input, buf)) return null
                    putPixel(px, index, w, hgt, bpp, buf, topOrigin)
                    index++
                }
            } else {
                // RLE compressed (type 10)
                while (index < total) {
                    val hb = input.read()
                    if (hb < 0) return null
                    val count = (hb and 0x7F) + 1
                    if (hb and 0x80 != 0) {
                        if (!readFully(input, buf)) return null
                        for (k in 0 until count) {
                            if (index >= total) break
                            putPixel(px, index, w, hgt, bpp, buf, topOrigin)
                            index++
                        }
                    } else {
                        for (k in 0 until count) {
                            if (index >= total) break
                            if (!readFully(input, buf)) return null
                            putPixel(px, index, w, hgt, bpp, buf, topOrigin)
                            index++
                        }
                    }
                }
            }
            Bitmap.createBitmap(px, w, hgt, Bitmap.Config.ARGB_8888)
        } catch (e: Exception) {
            null
        }
    }

    private fun putPixel(px: IntArray, index: Int, w: Int, h: Int, bpp: Int, buf: ByteArray, topOrigin: Boolean) {
        val b = buf[0].toInt() and 0xFF
        val g = buf[1].toInt() and 0xFF
        val r = buf[2].toInt() and 0xFF
        val a = if (bpp == 4) buf[3].toInt() and 0xFF else 255
        val x = index % w
        val row = index / w
        val y = if (topOrigin) row else h - 1 - row
        px[y * w + x] = Color.argb(a, r, g, b)
    }

    fun encode(bmp: Bitmap, out: OutputStream): Boolean {
        return try {
            val w = bmp.width
            val h = bmp.height
            val hdr = ByteArray(18)
            hdr[2] = 2 // uncompressed true-color
            hdr[12] = (w and 0xFF).toByte()
            hdr[13] = ((w shr 8) and 0xFF).toByte()
            hdr[14] = (h and 0xFF).toByte()
            hdr[15] = ((h shr 8) and 0xFF).toByte()
            hdr[16] = 32 // 32-bit BGRA
            hdr[17] = (8 or 0x20).toByte() // 8 alpha bits, top-left origin
            out.write(hdr)
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            val buf = ByteArray(4)
            for (c in px) {
                buf[0] = (c and 0xFF).toByte()          // B
                buf[1] = ((c shr 8) and 0xFF).toByte()  // G
                buf[2] = ((c shr 16) and 0xFF).toByte() // R
                buf[3] = ((c ushr 24) and 0xFF).toByte()// A
                out.write(buf)
            }
            out.flush()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun readFully(input: InputStream, buf: ByteArray): Boolean {
        var off = 0
        while (off < buf.size) {
            val n = input.read(buf, off, buf.size - off)
            if (n < 0) return false
            off += n
        }
        return true
    }
}
