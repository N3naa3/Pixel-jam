package com.pixelpack.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

enum class Tool { PENCIL, ERASER, FILL, PICKER, SELECT, HAND, WAND }

class PixelView(context: Context) : View(context) {

    var bitmap: Bitmap = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
        private set

    var tool: Tool = Tool.PENCIL
    var currentColor: Int = Color.BLACK
    var onColorPicked: ((Int) -> Unit)? = null
    var onSelectionChanged: ((Boolean) -> Unit)? = null

    var showGrid: Boolean = true
        set(value) { field = value; invalidate() }

    var brushSize = 1
    var eraserSize = 1

    var ghostN = 0
        private set

    var hasSelection: Boolean = false
        private set

    private var selX = 0
    private var selY = 0
    private var selW = 0
    private var selH = 0
    private var selOriginX = 0
    private var selOriginY = 0
    private var selBmp: Bitmap? = null
    private var selCut = false
    private var selMask: Bitmap? = null
    private var selIsPaste = false

    private var marActive = false
    private var marX0 = 0
    private var marY0 = 0
    private var marX1 = 0
    private var marY1 = 0

    private var moveDrag = false
    private var moveOffX = 0
    private var moveOffY = 0

    private var handDrag = false
    private var handLastX = 0f
    private var handLastY = 0f

    private var checker: Bitmap = makeChecker(32, 32)
    private val undoStack = ArrayList<Bitmap>()
    private val redoStack = ArrayList<Bitmap>()

    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var needFit = true

    private val bmpPaint = Paint()
    private val ghostPaint = Paint()
    private val gridPaint = Paint()
    private val clearPaint = Paint()
    private val borderBlack = Paint()
    private val borderWhite = Paint()
    private val selBtnPaint = Paint()
    private val iconPaint = Paint()

    private var strokeActive = false
    private var lastPx = 0
    private var lastPy = 0
    private var multi = false
    private var lastFx = Float.NaN
    private var lastFy = Float.NaN

    private val density: Float get() = resources.displayMetrics.density
    private val selBtnSize: Float get() = 36f * density
    private val selBtnGap: Float get() = 6f * density

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val newScale = (scale * detector.scaleFactor).coerceIn(0.5f, 80f)
                val real = newScale / scale
                tx = detector.focusX - (detector.focusX - tx) * real
                ty = detector.focusY - (detector.focusY - ty) * real
                scale = newScale
                invalidate()
                return true
            }
        }
    )

    init {
        bmpPaint.isFilterBitmap = false
        bmpPaint.isAntiAlias = false
        ghostPaint.isFilterBitmap = false
        ghostPaint.isAntiAlias = false
        ghostPaint.alpha = 110
        gridPaint.color = Color.argb(90, 0, 0, 0)
        gridPaint.strokeWidth = 1f
        clearPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        borderBlack.color = Color.BLACK
        borderBlack.style = Paint.Style.STROKE
        borderBlack.strokeWidth = 4f
        borderWhite.color = Color.WHITE
        borderWhite.style = Paint.Style.STROKE
        borderWhite.strokeWidth = 2f
        borderWhite.pathEffect = DashPathEffect(floatArrayOf(10f, 6f), 0f)
        selBtnPaint.color = Color.argb(215, 45, 45, 45)
        selBtnPaint.style = Paint.Style.FILL
        iconPaint.color = Color.WHITE
        iconPaint.style = Paint.Style.STROKE
        iconPaint.strokeWidth = 2.2f * density
        iconPaint.isAntiAlias = true
        iconPaint.strokeCap = Paint.Cap.ROUND
    }

    var compareBitmap: Bitmap? = null
        set(value) { field = value; invalidate() }
    private val comparePaint = Paint()

    private var rzActive = false
    private var rzW = 0
    private var rzH = 0
    private var rzX = 0
    private var rzY = 0
    private val rzPaint = Paint()
    private val rzLine = Paint()

    init {
        comparePaint.isFilterBitmap = false
        comparePaint.alpha = 140
        rzPaint.color = Color.argb(130, 255, 0, 0)
        rzLine.color = Color.WHITE
        rzLine.style = Paint.Style.STROKE
    }

    // ---------- PUBLIC API ----------

    fun replaceWith(b: Bitmap) {
        stampSelection()
        pushUndo()
        applyBitmap(copyOf(b), false)
    }

    fun loadBitmap(b: Bitmap) {
        stampSelection()
        undoStack.clear()
        redoStack.clear()
        applyBitmap(copyOf(b), true)
    }

    fun newCanvas(w: Int, h: Int) {
        loadBitmap(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))
    }

    fun resizeCanvas(w: Int, h: Int) {
        stampSelection()
        pushUndo()
        val nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(nb).drawBitmap(bitmap, 0f, 0f, null)
        applyBitmap(nb, true)
    }

    fun clearCanvas() {
        stampSelection()
        pushUndo()
        bitmap.eraseColor(Color.TRANSPARENT)
        invalidate()
    }

    // NEW: Smoothly replaces colors across the whole canvas in one undo step
    fun replaceColor(target: Int, replacement: Int) {
        pushUndo()
        val w = bitmap.width
        val h = bitmap.height
        val px = IntArray(w * h)
        bitmap.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            if (px[i] == target) px[i] = replacement
        }
        bitmap.setPixels(px, 0, w, 0, 0, w, h)
        invalidate()
    }

    fun setResizePreview(w: Int, h: Int, offX: Int, offY: Int) {
        rzActive = true; rzW = w; rzH = h; rzX = offX; rzY = offY
        invalidate()
    }

    fun clearResizePreview() { rzActive = false; invalidate() }

    fun resizeCanvasAnchored(w: Int, h: Int, offX: Int, offY: Int) {
        stampSelection()
        pushUndo()
        val nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(nb).drawBitmap(bitmap, (-offX).toFloat(), (-offY).toFloat(), null)
        rzActive = false
        applyBitmap(nb, true)
    }

    private fun drawMinus(canvas: Canvas, a: Rect, b: Rect) {
        val l = maxOf(a.left, b.left); val t = maxOf(a.top, b.top)
        val r = minOf(a.right, b.right); val bt = minOf(a.bottom, b.bottom)
        if (l >= r || t >= bt) { canvas.drawRect(a, rzPaint); return }
        if (l > a.left) canvas.drawRect(a.left.toFloat(), a.top.toFloat(), l.toFloat(), a.bottom.toFloat(), rzPaint)
        if (r < a.right) canvas.drawRect(r.toFloat(), a.top.toFloat(), a.right.toFloat(), a.bottom.toFloat(), rzPaint)
        if (t > a.top) canvas.drawRect(l.toFloat(), a.top.toFloat(), r.toFloat(), t.toFloat(), rzPaint)
        if (bt < a.bottom) canvas.drawRect(l.toFloat(), bt.toFloat(), r.toFloat(), a.bottom.toFloat(), rzPaint)
    }

    fun undo() {
        stampSelection()
        if (undoStack.isEmpty()) return
        redoStack.add(copyOf(bitmap))
        applyBitmap(undoStack.removeAt(undoStack.size - 1), false)
    }

    fun redo() {
        stampSelection()
        if (redoStack.isEmpty()) return
        undoStack.add(copyOf(bitmap))
        applyBitmap(redoStack.removeAt(redoStack.size - 1), false)
    }

    fun setGhost(n: Int) {
        ghostN = n.coerceIn(0, 5)
        invalidate()
    }

    fun beginPaste(src: Bitmap) {
        stampSelection()
        pushUndo()
        var b = src
        if (b.width > bitmap.width || b.height > bitmap.height) {
            val s = min(bitmap.width.toFloat() / b.width, bitmap.height.toFloat() / b.height)
            val nw = max(1, (b.width * s).toInt())
            val nh = max(1, (b.height * s).toInt())
            val nb = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888)
            Canvas(nb).drawBitmap(b, null, Rect(0, 0, nw, nh), bmpPaint)
            b = nb
        }
        setSelection(b, (bitmap.width - b.width) / 2, (bitmap.height - b.height) / 2, false)
        selIsPaste = true
    }

    fun copySelection() {
        if (!hasSelection) return
        if (selCut) {
            val b = selBmp ?: return
            Canvas(bitmap).drawBitmap(b, selOriginX.toFloat(), selOriginY.toFloat(), null)
            selCut = false
            invalidate()
        }
    }

    fun selectColorAt(x: Int, y: Int) {
        if (!inside(x, y)) return
        stampSelection()
        val target = bitmap.getPixel(x, y)
        val w = bitmap.width; val h = bitmap.height
        val px = IntArray(w * h)
        bitmap.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (yy in 0 until h) {
            for (xx in 0 until w) {
                if (px[yy * w + xx] == target) {
                    if (xx < minX) minX = xx; if (xx > maxX) maxX = xx
                    if (yy < minY) minY = yy; if (yy > maxY) maxY = yy
                }
            }
        }
        if (maxX < 0) return
        val bw = maxX - minX + 1; val bh = maxY - minY + 1
        pushUndo()
        val region = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        region.eraseColor(Color.TRANSPARENT)
        for (yy in minY..maxY) {
            for (xx in minX..maxX) {
                if (px[yy * w + xx] == target) region.setPixel(xx - minX, yy - minY, target)
            }
        }
        setSelection(region, minX, minY, false)
        selMask = region
    }

    fun rotateSelection() {
        val b = selBmp ?: return
        val nb = Bitmap.createBitmap(b.height, b.width, Bitmap.Config.ARGB_8888)
        val m = Matrix(); m.setRotate(90f); m.postTranslate(b.height.toFloat(), 0f)
        Canvas(nb).drawBitmap(b, m, null)
        selBmp = nb; selW = nb.width; selH = nb.height
        clampSelection(); invalidate()
    }

    fun flipSelection(horizontal: Boolean) {
        val b = selBmp ?: return
        val nb = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val m = Matrix()
        if (horizontal) { m.setScale(-1f, 1f); m.postTranslate(b.width.toFloat(), 0f) } 
        else { m.setScale(1f, -1f); m.postTranslate(0f, b.height.toFloat()) }
        Canvas(nb).drawBitmap(b, m, null)
        selBmp = nb; invalidate()
    }

    fun stampSelection() {
        if (!hasSelection) return
        val b = selBmp ?: return
        Canvas(bitmap).drawBitmap(b, selX.toFloat(), selY.toFloat(), null)
        clearSel(); invalidate()
    }

    fun cancelSelection() {
        if (!hasSelection) return
        if (selCut) {
            val b = selBmp ?: return
            Canvas(bitmap).drawBitmap(b, selOriginX.toFloat(), selOriginY.toFloat(), null)
        }
        clearSel(); invalidate()
    }

    fun deleteSelection() {
        if (!hasSelection) return
        val m = selMask
        if (m != null) {
            for (yy in 0 until m.height) {
                for (xx in 0 until m.width) {
                    if (Color.alpha(m.getPixel(xx, yy)) > 0) {
                        val cx = selOriginX + xx; val cy = selOriginY + yy
                        if (inside(cx, cy)) bitmap.setPixel(cx, cy, Color.TRANSPARENT)
                    }
                }
            }
        }
        clearSel(); invalidate()
    }

    // ---------- INTERNALS ----------

    private fun setSelection(b: Bitmap, x: Int, y: Int, cut: Boolean) {
        selBmp = b; selX = x; selY = y; selW = b.width; selH = b.height
        selOriginX = x; selOriginY = y; selCut = cut; selMask = null; selIsPaste = false
        hasSelection = true; onSelectionChanged?.invoke(true); invalidate()
    }

    private fun clearSel() {
        hasSelection = false; selBmp = null; selMask = null; selIsPaste = false
        onSelectionChanged?.invoke(false)
    }

    private fun clampSelection() {
        selX = selX.coerceIn(-selW + 1, bitmap.width - 1)
        selY = selY.coerceIn(-selH + 1, bitmap.height - 1)
    }

    private fun commitMarquee() {
        val l = min(marX0, marX1); val t = min(marY0, marY1)
        val w = max(marX0, marX1) - l + 1; val h = max(marY0, marY1) - t + 1
        if (w <= 0 || h <= 0) return
        pushUndo()
        val region = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(region).drawBitmap(bitmap, Rect(l, t, l + w, t + h), Rect(0, 0, w, h), bmpPaint)
        Canvas(bitmap).drawRect(Rect(l, t, l + w, t + h), clearPaint)
        setSelection(region, l, t, true)
    }

    private fun selButtonRect(i: Int): RectF {
        val size = selBtnSize; val gap = selBtnGap
        val left = tx + (selX + selW) * scale + gap
        val top = ty + selY * scale + i * (size + gap)
        return RectF(left, top, left + size, top + size)
    }

    private fun drawSelIcon(canvas: Canvas, i: Int, rf: RectF) {
        val s = rf.width()
        if (i == 0) {
            canvas.drawRect(RectF(rf.left + s * 0.20f, rf.top + s * 0.16f, rf.left + s * 0.58f, rf.top + s * 0.54f), iconPaint)
            canvas.drawRect(RectF(rf.left + s * 0.40f, rf.top + s * 0.40f, rf.left + s * 0.80f, rf.top + s * 0.80f), iconPaint)
        } else if (i == 1) {
            val cx = rf.centerX(); val cy = rf.centerY(); val r = s * 0.27f
            val path = Path(); path.addArc(RectF(cx - r, cy - r, cx + r, cy + r), 45f, 270f)
            canvas.drawPath(path, iconPaint)
            val ang = Math.toRadians(315.0); val ex = (cx + r * Math.cos(ang)).toFloat(); val ey = (cy + r * Math.sin(ang)).toFloat()
            val aLen = s * 0.20f; val tipX = ex + 0.7071f * aLen; val tipY = ey + 0.7071f * aLen; val wHalf = s * 0.10f
            canvas.drawLine(ex + 0.7071f * wHalf, ey - 0.7071f * wHalf, tipX, tipY, iconPaint)
            canvas.drawLine(ex - 0.7071f * wHalf, ey + 0.7071f * wHalf, tipX, tipY, iconPaint)
        } else if (i == 2) {
            val x1 = rf.left + s * 0.32f; val x2 = rf.left + s * 0.68f
            canvas.drawLine(x1, rf.top + s * 0.74f, x1, rf.top + s * 0.32f, iconPaint)
            canvas.drawLine(x1, rf.top + s * 0.28f, x1 - s * 0.11f, rf.top + s * 0.44f, iconPaint)
            canvas.drawLine(x1, rf.top + s * 0.28f, x1 + s * 0.11f, rf.top + s * 0.44f, iconPaint)
            canvas.drawLine(x2, rf.top + s * 0.26f, x2, rf.top + s * 0.68f, iconPaint)
            canvas.drawLine(x2, rf.top + s * 0.72f, x2 - s * 0.11f, rf.top + s * 0.56f, iconPaint)
            canvas.drawLine(x2, rf.top + s * 0.72f, x2 + s * 0.11f, rf.top + s * 0.56f, iconPaint)
        } else if (i == 3) {
            val cx = rf.centerX(); val cy = rf.centerY(); val k = s * 0.14f
            canvas.drawCircle(cx, cy, s * 0.28f, iconPaint)
            canvas.drawLine(cx - k, cy - k, cx + k, cy + k, iconPaint)
            canvas.drawLine(cx + k, cy - k, cx - k, cy + k, iconPaint)
        } else {
            val p = Path()
            p.moveTo(rf.left + s * 0.18f, rf.top + s * 0.58f); p.lineTo(rf.left + s * 0.46f, rf.top + s * 0.24f)
            p.lineTo(rf.left + s * 0.82f, rf.top + s * 0.50f); p.lineTo(rf.left + s * 0.54f, rf.top + s * 0.84f); p.close()
            canvas.drawPath(p, iconPaint)
            canvas.drawLine(rf.left + s * 0.32f, rf.top + s * 0.41f, rf.left + s * 0.68f, rf.top + s * 0.67f, iconPaint)
        }
    }

    private fun makeChecker(w: Int, h: Int): Bitmap {
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) px[y * w + x] = if ((x + y) % 2 == 0) Color.rgb(166, 166, 166) else Color.rgb(204, 204, 204)
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun copyOf(b: Bitmap): Bitmap {
        val c = b.copy(Bitmap.Config.ARGB_8888, true)
        return c ?: Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
    }

    private fun applyBitmap(b: Bitmap, refit: Boolean) {
        val sizeChanged = b.width != checker.width || b.height != checker.height
        bitmap = b
        if (sizeChanged) checker = makeChecker(b.width, b.height)
        if (refit || sizeChanged) needFit = true
        fitIfNeeded(); invalidate()
    }

    private fun pushUndo() {
        undoStack.add(copyOf(bitmap))
        if (undoStack.size > 40) undoStack.removeAt(0)
        redoStack.clear()
    }

    private fun fitIfNeeded() {
        if (!needFit || width == 0 || height == 0) return
        var s = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        if (s >= 1f) s = floor(s)
        scale = s; tx = (width - bitmap.width * s) / 2f; ty = (height - bitmap.height * s) / 2f
        needFit = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (oldw == 0 || oldh == 0) { needFit = true; fitIfNeeded(); return }
        val cx = (oldw / 2f - tx) / scale; val cy = (oldh / 2f - ty) / scale
        tx = w / 2f - cx * scale; ty = h / 2f - cy * scale
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.rgb(32, 32, 32))
        canvas.save()
        canvas.translate(tx, ty); canvas.scale(scale, scale)
        canvas.drawBitmap(checker, 0f, 0f, bmpPaint)
        canvas.drawBitmap(bitmap, 0f, 0f, bmpPaint)
        val cmp = compareBitmap
        if (cmp != null) canvas.drawBitmap(cmp, 0f, 0f, comparePaint)
        if (rzActive) {
            val oldR = Rect(0, 0, bitmap.width, bitmap.height)
            val newR = Rect(rzX, rzY, rzX + rzW, rzY + rzH)
            drawMinus(canvas, oldR, newR); drawMinus(canvas, newR, oldR)
            rzLine.strokeWidth = 2f / scale; canvas.drawRect(newR, rzLine)
        }
        if (ghostN > 1) {
            val gw = bitmap.width.toFloat(); val gh = bitmap.height.toFloat()
            for (gy in 0 until ghostN) for (gx in 0 until ghostN) {
                if (gx == 0 && gy == 0) continue
                canvas.drawBitmap(checker, gx * gw, gy * gh, bmpPaint)
                canvas.drawBitmap(bitmap, gx * gw, gy * gh, bmpPaint)
            }
        }
        canvas.restore()
        if (showGrid && scale >= 8f) {
            val w = bitmap.width; val h = bitmap.height
            val right = tx + w * scale; val bottom = ty + h * scale
            val vw = width.toFloat(); val vh = height.toFloat()
            for (x in 0..w) { val sx = tx + x * scale; if (sx in 0f..vw) canvas.drawLine(sx, ty, sx, bottom, gridPaint) }
            for (y in 0..h) { val sy = ty + y * scale; if (sy in 0f..vh) canvas.drawLine(tx, sy, right, sy, gridPaint) }
        }
        if (marActive) {
            val rf = RectF(tx + min(marX0, marX1) * scale, ty + min(marY0, marY1) * scale, tx + (max(marX0, marX1) + 1) * scale, ty + (max(marY0, marY1) + 1) * scale)
            canvas.drawRect(rf, borderBlack); canvas.drawRect(rf, borderWhite)
        }
        val sb = selBmp
        if (hasSelection && sb != null) {
            val l = tx + selX * scale; val t = ty + selY * scale
            val rf = RectF(l, t, l + selW * scale, t + selH * scale)
            canvas.drawBitmap(sb, null, rf, ghostPaint)
            canvas.save(); canvas.clipRect(tx, ty, tx + bitmap.width * scale, ty + bitmap.height * scale)
            canvas.drawBitmap(sb, null, rf, bmpPaint); canvas.restore()
            canvas.drawRect(rf, borderBlack); canvas.drawRect(rf, borderWhite)
            for (i in 0 until 5) { val br = selButtonRect(i); canvas.drawRect(br, selBtnPaint); drawSelIcon(canvas, i, br) }
        }
    }

    private fun toPx(sx: Float): Int = floor((sx - tx) / scale).toInt()
    private fun toPy(sy: Float): Int = floor((sy - ty) / scale).toInt()
    private fun inside(x: Int, y: Int): Boolean = x >= 0 && y >= 0 && x < bitmap.width && y < bitmap.height

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false; lastFx = Float.NaN
                var consumed = false
                if (!consumed && hasSelection) {
                    var hitBtn = -1
                    for (i in 0 until 5) {
                        val br = selButtonRect(i)
                        if (ev.x >= br.left && ev.x <= br.right && ev.y >= br.top && ev.y <= br.bottom) { hitBtn = i; break }
                    }
                    if (hitBtn >= 0) {
                        when (hitBtn) { 0 -> copySelection(); 1 -> rotateSelection(); 2 -> flipSelection(false); 3 -> cancelSelection(); else -> deleteSelection() }
                        consumed = true
                    }
                }
                if (!consumed) {
                    val px = toPx(ev.x); val py = toPy(ev.y)
                    if (hasSelection) {
                        if (nearSelection(ev.x, ev.y) && (tool == Tool.SELECT || selIsPaste)) { moveDrag = true; moveOffX = px - selX; moveOffY = py - selY } 
                        else stampSelection()
                    }
                    if (!moveDrag) {
                        if (tool == Tool.HAND) { handDrag = true; handLastX = ev.x; handLastY = ev.y } 
                        else if (tool == Tool.SELECT) { if (inside(px, py)) { marActive = true; marX0 = px; marY0 = py; marX1 = px; marY1 = py; invalidate() } } 
                        else startStroke(px, py)
                    }
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> { if (strokeActive) cancelStroke(); moveDrag = false; handDrag = false; marActive = false; multi = true; lastFx = Float.NaN; invalidate() }
            MotionEvent.ACTION_MOVE -> {
                if (ev.pointerCount >= 2) {
                    var fx = 0f; var fy = 0f
                    for (i in 0 until ev.pointerCount) { fx += ev.getX(i); fy += ev.getY(i) }
                    fx /= ev.pointerCount; fy /= ev.pointerCount
                    if (!lastFx.isNaN()) { tx += fx - lastFx; ty += fy - lastFy; invalidate() }
                    lastFx = fx; lastFy = fy
                } else if (handDrag) { tx += ev.x - handLastX; ty += ev.y - handLastY; handLastX = ev.x; handLastY = ev.y; invalidate() } 
                else if (moveDrag) {
                    val oldL = (tx + selX * scale).toInt(); val oldT = (ty + selY * scale).toInt()
                    val oldR = (tx + (selX + selW) * scale).toInt() + 1; val oldB = (ty + (selY + selH) * scale).toInt() + 1
                    selX = (toPx(ev.x) - moveOffX).coerceIn(-selW + 1, bitmap.width - 1)
                    selY = (toPy(ev.y) - moveOffY).coerceIn(-selH + 1, bitmap.height - 1)
                    val newL = (tx + selX * scale).toInt(); val newT = (ty + selY * scale).toInt()
                    val newR = (tx + (selX + selW) * scale).toInt() + 1; val newB = (ty + (selY + selH) * scale).toInt() + 1
                    val btnExt = (selBtnSize + selBtnGap).toInt(); val colH = (5f * (selBtnSize + selBtnGap)).toInt()
                    val oldB2 = max(oldB, (ty + selY * scale).toInt() + colH); val newB2 = max(newB, (ty + selY * scale).toInt() + colH)
                    invalidate(min(oldL, newL) - 8, min(oldT, newT) - 8, max(oldR, newR) + btnExt + 8, max(oldB2, newB2) + 8)
                } else if (marActive) { marX1 = toPx(ev.x).coerceIn(0, bitmap.width - 1); marY1 = toPy(ev.y).coerceIn(0, bitmap.height - 1); invalidate() } 
                else if (!multi && strokeActive) continueStroke(toPx(ev.x), toPy(ev.y))
            }
            MotionEvent.ACTION_POINTER_UP -> lastFx = Float.NaN
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (marActive && ev.actionMasked == MotionEvent.ACTION_UP) commitMarquee()
                marActive = false; moveDrag = false; handDrag = false; strokeActive = false; multi = false; lastFx = Float.NaN
            }
        }
        return true
    }

    private fun nearSelection(sx: Float, sy: Float): Boolean {
        val slop = 18f * density
        val l = tx + selX * scale; val t = ty + selY * scale
        val r = tx + (selX + selW) * scale; val b = ty + (selY + selH) * scale
        return sx >= l - slop && sx <= r + slop && sy >= t - slop && sy <= b + slop
    }

    private fun startStroke(x: Int, y: Int) {
        if (!inside(x, y)) return
        when (tool) {
            Tool.PENCIL, Tool.ERASER -> { pushUndo(); strokeActive = true; lastPx = x; lastPy = y; plot(x, y); invalidate() }
            Tool.FILL -> { pushUndo(); floodFill(x, y, currentColor); invalidate() }
            Tool.PICKER -> { val c = bitmap.getPixel(x, y); if (Color.alpha(c) > 0) { currentColor = c; onColorPicked?.invoke(c) } }
            Tool.WAND -> selectColorAt(x, y)
            else -> {}
        }
    }

    private fun continueStroke(x: Int, y: Int) {
        if (x == lastPx && y == lastPy) return
        line(lastPx, lastPy, x, y); lastPx = x; lastPy = y; invalidate()
    }

    private fun cancelStroke() {
        strokeActive = false
        if (undoStack.isNotEmpty()) applyBitmap(undoStack.removeAt(undoStack.size - 1), false)
    }

    private fun plot(x: Int, y: Int) {
        if (!inside(x, y)) return
        val c: Int; var n = 1
        if (tool == Tool.ERASER) { c = Color.TRANSPARENT; n = eraserSize } 
        else { c = currentColor; if (tool == Tool.PENCIL) n = brushSize }
        for (dy in 0 until n) for (dx in 0 until n) { val xx = x + dx; val yy = y + dy; if (inside(xx, yy)) bitmap.setPixel(xx, yy, c) }
    }

    private fun line(x0: Int, y0: Int, x1: Int, y1: Int) {
        var x = x0; var y = y0
        val dx = abs(x1 - x0); val dy = -abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1; val sy = if (y0 < y1) 1 else -1
        var err = dx + dy
        while (true) {
            plot(x, y); if (x == x1 && y == y1) break
            val e2 = 2 * err
            if (e2 >= dy) { err += dy; x += sx }
            if (e2 <= dx) { err += dx; y += sy }
        }
    }

    private fun floodFill(sx: Int, sy: Int, fill: Int) {
        val w = bitmap.width; val h = bitmap.height
        val px = IntArray(w * h)
        bitmap.getPixels(px, 0, w, 0, 0, w, h)
        val target = px[sy * w + sx]
        if (target == fill) return
        val stack = IntArray(w * h * 4 + 8)
        var sp = 0
        stack[sp] = sy * w + sx; sp++
        while (sp > 0) {
            sp--; val p = stack[sp]
            if (px[p] != target) continue
            px[p] = fill
            val x = p % w; val y = p / w
            if (x > 0 && px[p - 1] == target) { stack[sp] = p - 1; sp++ }
            if (x < w - 1 && px[p + 1] == target) { stack[sp] = p + 1; sp++ }
            if (y > 0 && px[p - w] == target) { stack[sp] = p - w; sp++ }
            if (y < h - 1 && px[p + w] == target) { stack[sp] = p + w; sp++ }
        }
        bitmap.setPixels(px, 0, w, 0, 0, w, h)
    }
}